# viz/ — the interactive model figure

Two files plus a JSON bridge between them.

```
viz/
  export_traces.py   runs the model, writes traces.json
  traces.json        generated, not committed
  model_viz.html     reads traces.json, falls back to synthetic if absent
  README_viz.md      this file
```

## Running it

```bash
python viz/export_traces.py --out viz/traces.json
cd viz && python -m http.server 8000
# open http://localhost:8000/model_viz.html
```

The page must be served, not opened as `file://`, or the `fetch` of
`traces.json` is blocked by CORS and it silently falls back to synthetic data.
Check the bottom-right corner: it reads `source: traces.json · <timestamp>`
when real data loaded, and `source: synthetic placeholder` when it did not.

## What still needs wiring

`export_traces.py` has two `TODO` blocks. Everything else is complete: the
metric functions implement Methods 4.5 of the first-year report exactly
(spike detection at −10 mV, 25 ms analysis window, reliability, onset jitter as
the across-trial SD of first-spike latency averaged over the 8 commands,
inter-burst spikes per trial, and the command-driven criterion).

- **TODO 1 `run_trial(g_total_nS, rate_hz, seed)`** — run one 500 ms trial and
  return `t_ms`, `vm_mV`, `hvc_spikes`, `lman_spikes`. The HVC motif must be
  identical on every trial; only the LMAN Poisson trains vary with `seed`.
- **TODO 2 `load_existing_sweep()`** — if the Figure 5B sweep is already cached
  somewhere in the repo, return it and skip 160 extra simulations. Otherwise
  leave it returning `None`.

## Prompt for Claude Code

Paste this from the repo root:

> I have added `viz/export_traces.py`, which produces a JSON file for a
> presentation figure. It has two unimplemented functions marked TODO 1 and
> TODO 2. Please wire them to the existing NEURON model in this repository.
>
> For `run_trial(g_total_nS, rate_hz, seed)`: find the existing code that
> builds the single-compartment RA projection neuron, attaches the 40 HVC AMPA
> synapses (11 nS total, 8 bursts of 4 spikes at 650 Hz) and the 2 independent
> LMAN NMDA axons, and runs a 500 ms simulation at 40 °C with a −0.3 nA holding
> current. Reuse it rather than rewriting it. The function must:
> - split `g_total_nS` equally across the LMAN axons
> - drive each LMAN axon with an independent Poisson train at `rate_hz`,
>   seeded from `seed`, so trains differ between trials
> - keep the HVC burst motif identical on every trial
> - record the somatic membrane potential and return
>   `{"t_ms": [...], "vm_mV": [...], "hvc_spikes": [...], "lman_spikes": [[...], [...]]}`
>   with all times in ms
>
> For `load_existing_sweep()`: check whether the Figure 5B sweep (jitter across
> LMAN conductance 1, 3, 5, 7, 10 nS against rates 5, 10, 21, 35 Hz) is already
> saved anywhere in the repo. If it is, load and return it in the documented
> shape. If not, leave it returning None.
>
> Do not change the metric functions, the constants at the top, or the JSON
> schema; the HTML depends on them. Do not modify any existing model code —
> only import from it.
>
> When done, run `python viz/export_traces.py --out viz/traces.json` and show
> me the printed summary. Confirm that the 3 nS case comes out command-driven
> and that the 5 and 9.5 nS cases do not. If any case disagrees with Figure 5,
> stop and tell me rather than adjusting parameters to force a match.

That last sentence matters. If the export disagrees with the figure in the
report, that is information, not a bug to be tuned away.

## The three cases

Ordered physiological-first, which is the order the argument wants:

| case | what it is | expected |
|---|---|---|
| 5 nS | one measured LMAN fibre | decoupled |
| 9.5 nS | maximal recruitment | decoupled |
| 3 nS | model operating point, sub-physiological | locked |

The point of that ordering: the audience sees the physiologically real case
fail first, then sees it fail worse at full drive, and only then learns that
the one setting where the neuron holds its lock is below anything measured in a
real bird. Ending on the locked case is what makes the gap land.

## Aesthetic decisions

- HVC top-left, LMAN bottom-left, RA PN centre, matching the microcircuit
  slides so the geometry carries across the talk. Same palette throughout.
- The RA PN trace and the HVC-locked target trace sit in a box that turns green
  when the case is command-driven and red when it is not. Both boxes change
  together, so the comparison being made is unambiguous.
- All four traces share one mV axis with gridlines at −65 and 0, and there is a
  single time axis in ms underneath.
- The grid shows every value at all times. The button below it dims everything
  except the 21 Hz column, so you can open on the full sweep, say that only
  directed singing is under discussion, and clear the rest.
