#!/usr/bin/env python3
"""
Generate the RA microcircuit SVG set for the first-year viva deck.

All microcircuit files share one coordinate space (1600 x 900) and one set of
element ids, so PowerPoint Morph / Keynote Magic Move can match objects between
slides. Element ids become object names on import to Illustrator.

Palette (Figure 1 of the report):
  HVC   teal    #1B9AAA   fast, AMPA, on spines
  LMAN  orange  #E4572E   slow, NMDA, shaft + spines
  IN    purple  #8B4FD8   inhibitory, on shaft  (DASHED = measured by this project)
  PN    navy    #1E2438 / stroke #A9B4D6
  bg            #101319
  text          #E6E8EC
  muted         #7C8598
"""

import math, os

W, H = 1600, 900

C = dict(
    hvc="#1B9AAA", hvc_dim="#164E57",
    lman="#E4572E", lman_dim="#5C2A1B",
    inh="#8B4FD8", inh_dim="#3D2258",
    pn="#1E2438", pn_stroke="#A9B4D6",
    bg="#101319", text="#E6E8EC", muted="#7C8598",
    dend="#C3CBE0",
)

OUT = "/home/claude/svg"
os.makedirs(OUT, exist_ok=True)

# ----------------------------------------------------------------------------
# Dendritic geometry. Named segments, identical in every timepoint file.
# ----------------------------------------------------------------------------
SOMA = (760.0, 706.0)

SEG = {
    "trunk": ((760, 656), (760, 494)),
    "L1":    ((760, 494), (592, 386)),
    "L2":    ((592, 386), (452, 268)),
    "L3":    ((592, 386), (612, 226)),
    "R1":    ((760, 494), (940, 396)),
    "R2":    ((940, 396), (916, 236)),
    "R3":    ((940, 396), (1096, 292)),
}
SEG_W = {"trunk": 18, "L1": 13, "R1": 13, "L2": 8, "L3": 8, "R2": 8, "R3": 8}


def pt(seg, t):
    (x1, y1), (x2, y2) = SEG[seg]
    return (x1 + (x2 - x1) * t, y1 + (y2 - y1) * t)


def nrm(seg, side):
    (x1, y1), (x2, y2) = SEG[seg]
    dx, dy = x2 - x1, y2 - y1
    L = math.hypot(dx, dy)
    return (-dy / L * side, dx / L * side)


# ----------------------------------------------------------------------------
# Fixed synaptic sites. Stable ids across timepoints -> clean morph.
# SPINES: (id, segment, t, side)   SHAFT: (id, segment, t, side)
# ----------------------------------------------------------------------------
SPINES = [
    ("sp01", "L2", 0.30, +1), ("sp02", "L2", 0.62, -1), ("sp03", "L2", 0.86, +1),
    ("sp04", "L3", 0.34, -1), ("sp05", "L3", 0.68, +1),
    ("sp06", "L1", 0.46, +1), ("sp07", "L1", 0.78, -1),
    ("sp08", "R2", 0.32, +1), ("sp09", "R2", 0.66, -1), ("sp10", "R2", 0.88, +1),
    ("sp11", "R3", 0.36, -1), ("sp12", "R3", 0.70, +1),
    ("sp13", "R1", 0.44, -1), ("sp14", "R1", 0.76, +1),
    ("sp15", "trunk", 0.34, +1), ("sp16", "trunk", 0.70, -1),
]

SHAFTS = [
    ("sh01", "trunk", 0.18, -1), ("sh02", "trunk", 0.50, +1), ("sh03", "trunk", 0.84, -1),
    ("sh04", "L1", 0.30, -1),    ("sh05", "L1", 0.62, +1),
    ("sh06", "R1", 0.28, +1),    ("sh07", "R1", 0.60, -1),
    ("sh08", "L2", 0.48, -1),    ("sh09", "R2", 0.50, +1),
    ("sh10", "L3", 0.52, +1),    ("sh11", "R3", 0.54, -1),
]

# ----------------------------------------------------------------------------
# Per-timepoint occupancy.
#   spine occupant:  'hvc' | 'lman' | None
#   shaft occupant:  'lman' | 'in'  | None
#   state: 'on' = solid, 'ghost' = faded (not yet innervating), 'unknown' = dashed
# ----------------------------------------------------------------------------
def cfg_p25():
    """25 dph. HVC->RA immature (ghosted). LMAN dominant on shaft AND spine.
    Interneuron contacts dense and non-specific."""
    sp = {i: ("hvc", "ghost") for i in
          ["sp01", "sp05", "sp08", "sp12", "sp14"]}
    sp.update({i: ("lman", "on") for i in
               ["sp02", "sp03", "sp04", "sp06", "sp07", "sp09", "sp10",
                "sp11", "sp13", "sp15", "sp16"]})
    sh = {i: ("lman", "on") for i in
          ["sh01", "sh04", "sh06", "sh08", "sh09", "sh10", "sh11"]}
    sh.update({i: ("in", "unknown") for i in ["sh02", "sh03", "sh05", "sh07"]})
    return sp, sh, 0.92, "25 dph  ·  early subsong",\
        "HVC\u2192RA immature. LMAN drives shaft and spine. Interneuron contacts dense, non-specific."


def cfg_p50():
    """50 dph. Peak RA size: everything present and maximal."""
    sp = {i: ("hvc", "on") for i in
          ["sp01", "sp05", "sp08", "sp12", "sp14", "sp03", "sp10"]}
    sp.update({i: ("lman", "on") for i in
               ["sp02", "sp04", "sp06", "sp07", "sp09", "sp11", "sp13",
                "sp15", "sp16"]})
    sh = {i: ("lman", "on") for i in
          ["sh01", "sh04", "sh06", "sh08", "sh09", "sh10", "sh11"]}
    sh.update({i: ("in", "unknown") for i in
               ["sh02", "sh03", "sh05", "sh07"]})
    return sp, sh, 1.08, "50 dph  ·  subsong \u2192 plastic",\
        "Peak RA size. HVC, LMAN and interneuron input all maximal."


def cfg_p70():
    """70 dph. HVC and LMAN already in adult configuration, song still variable.
    The interneurons are the open question."""
    sp = {i: ("hvc", "on") for i in
          ["sp01", "sp03", "sp05", "sp08", "sp10", "sp12", "sp14"]}
    sp.update({i: ("lman", "on") for i in ["sp06", "sp09", "sp15"]})
    sh = {i: ("lman", "on") for i in ["sh04", "sh08", "sh09", "sh11"]}
    sh.update({i: ("in", "unknown") for i in ["sh02", "sh05", "sh07"]})
    return sp, sh, 1.0, "70 dph  ·  late plastic song",\
        "HVC and LMAN already adult-like, yet song is still variable. What changes next?"


def cfg_p90():
    """90 dph / adult. Inhibition sits near LMAN input (the hypothesis)."""
    sp = {i: ("hvc", "on") for i in
          ["sp01", "sp03", "sp05", "sp08", "sp10", "sp12", "sp14"]}
    sp.update({i: ("lman", "on") for i in ["sp06", "sp09", "sp15"]})
    sh = {i: ("lman", "on") for i in ["sh04", "sh08", "sh09", "sh11"]}
    sh.update({i: ("in", "unknown") for i in ["sh05", "sh07", "sh02"]})
    return sp, sh, 1.0, "> 90 dph  ·  crystallised song",\
        "Interneurons predominantly HVC-driven; inhibition positioned near LMAN input."


# ----------------------------------------------------------------------------
# Drawing primitives
# ----------------------------------------------------------------------------
def head():
    return (f'<svg xmlns="http://www.w3.org/2000/svg" '
            f'xmlns:xlink="http://www.w3.org/1999/xlink" '
            f'viewBox="0 0 {W} {H}" width="{W}" height="{H}">\n')


def bg_layer():
    return (f'<g id="bg_slide">\n'
            f'  <rect id="bg_rect" x="0" y="0" width="{W}" height="{H}" fill="{C["bg"]}"/>\n'
            f'</g>\n')


def txt(x, y, s, size=22, fill=None, anchor="start", weight="400",
        family="Helvetica Neue, Helvetica, Arial, sans-serif",
        ident=None, style=""):
    fill = fill or C["text"]
    i = f' id="{ident}"' if ident else ""
    return (f'<text{i} x="{x}" y="{y}" font-family="{family}" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}" '
            f'style="{style}">{s}</text>\n')


def dendrite_group():
    """The passive skeleton: soma, dendrites, axon. Identical in all files."""
    g = ['<g id="pn_cell">\n']
    for name, ((x1, y1), (x2, y2)) in SEG.items():
        g.append(f'  <line id="dend_{name}" x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
                 f'stroke="{C["dend"]}" stroke-width="{SEG_W[name]}" stroke-linecap="round"/>\n')
    sx, sy = SOMA
    g.append(f'  <line id="pn_axon" x1="{sx}" y1="{sy+42}" x2="{sx}" y2="822" '
             f'stroke="{C["dend"]}" stroke-width="9" stroke-linecap="round"/>\n')
    g.append(f'  <path id="pn_axon_arrow" d="M {sx-12} 816 L {sx} 842 L {sx+12} 816 Z" '
             f'fill="{C["dend"]}"/>\n')
    g.append(f'  <ellipse id="pn_soma" cx="{sx}" cy="{sy}" rx="62" ry="50" '
             f'fill="{C["pn"]}" stroke="{C["pn_stroke"]}" stroke-width="3.5"/>\n')
    g.append(txt(sx, sy + 8, "RA PN", 21, C["text"], "middle", "600", ident="lbl_pn"))
    g.append(txt(sx, 872, "to nXIIts", 18, C["muted"], "middle", ident="lbl_nxiits"))
    g.append('</g>\n')
    return "".join(g)


def spine(sid, seg, t, side, occupant, state):
    """Neck + head. Bouton colour encodes the input; ghost = not yet innervating."""
    px, py = pt(seg, t)
    nx, ny = nrm(seg, side)
    neck = 23
    hx, hy = px + nx * neck, py + ny * neck
    g = [f'<g id="{sid}">\n']
    g.append(f'  <line id="{sid}_neck" x1="{px}" y1="{py}" x2="{hx}" y2="{hy}" '
             f'stroke="{C["dend"]}" stroke-width="5" stroke-linecap="round"/>\n')
    g.append(f'  <circle id="{sid}_head" cx="{hx}" cy="{hy}" r="10.5" fill="{C["dend"]}"/>\n')
    if occupant:
        bx, by = hx + nx * 16, hy + ny * 16
        if occupant == "hvc":
            col, r, op, dash = C["hvc"], 11, 1.0, ""
            if state == "ghost":
                col, op, dash = C["hvc_dim"], 0.35, ' stroke-dasharray="4 4"'
            g.append(f'  <circle id="{sid}_bouton_hvc" cx="{bx}" cy="{by}" r="{r}" '
                     f'fill="{col}" opacity="{op}" stroke="{C["hvc"]}" stroke-width="2"{dash}/>\n')
        else:
            g.append(f'  <circle id="{sid}_bouton_lman" cx="{bx}" cy="{by}" r="15" '
                     f'fill="{C["lman"]}" stroke="{C["lman"]}" stroke-width="2"/>\n')
    g.append('</g>\n')
    return "".join(g)


def shaft_syn(sid, seg, t, side, occupant, state):
    """LMAN shaft bouton (orange disc) or inhibitory contact (purple bar)."""
    px, py = pt(seg, t)
    nx, ny = nrm(seg, side)
    g = [f'<g id="{sid}">\n']
    if occupant == "lman":
        bx, by = px + nx * 17, py + ny * 17
        g.append(f'  <circle id="{sid}_bouton_lman" cx="{bx}" cy="{by}" r="14" '
                 f'fill="{C["lman"]}" stroke="{C["lman"]}" stroke-width="2"/>\n')
    elif occupant == "in":
        bx, by = px + nx * 17, py + ny * 17
        ang = math.degrees(math.atan2(ny, nx))
        dash = ' stroke-dasharray="5 4"' if state == "unknown" else ""
        fill = C['bg'] if state == 'unknown' else C['inh']
        g.append(f'  <rect id="{sid}_bouton_in" x="{bx-12}" y="{by-19}" width="24" height="38" '
                 f'rx="4" transform="rotate({ang-90} {bx} {by})" '
                 f'fill="{fill}" stroke="{C["inh"]}" stroke-width="3.5"{dash}/>\n')
    g.append('</g>\n')
    return "".join(g)


def source_boxes(hvc_state="on"):
    """HVC (upper left) and LMAN (lower right) input nuclei.
    Axons are drawn behind the cell so they read as passing under the dendrites."""
    g = ['<g id="inputs">\n']
    hop = 0.30 if hvc_state == "ghost" else 1.0
    hdash = ' stroke-dasharray="9 7"' if hvc_state == "ghost" else ""
    # ---- HVC: enters upper left, runs across the distal apical field ----
    g.append(f'  <rect id="box_hvc" x="88" y="150" width="264" height="112" rx="16" '
             f'fill="{C["hvc"]}" opacity="{0.16*hop:.3f}" stroke="{C["hvc"]}" stroke-width="3" stroke-opacity="{hop}"{hdash}/>\n')
    g.append(txt(220, 198, "HVC", 36, C["hvc"], "middle", "700", ident="lbl_hvc", style=f"opacity:{hop}"))
    g.append(txt(220, 232, "AMPA \u00b7 fast \u00b7 timed", 19, C["hvc"], "middle", ident="lbl_hvc_sub", style=f"opacity:{hop}"))
    g.append(f'  <path id="axon_hvc" d="M 352 214 C 460 206, 520 236, 566 288 '
             f'C 610 338, 700 348, 792 316" fill="none" stroke="{C["hvc"]}" '
             f'stroke-width="5.5" stroke-linecap="round" opacity="{hop}"{hdash}/>\n')
    g.append(f'  <path id="axon_hvc_b" d="M 566 288 C 520 314, 486 316, 452 306" '
             f'fill="none" stroke="{C["hvc"]}" stroke-width="4.5" stroke-linecap="round" opacity="{hop}"{hdash}/>\n')
    g.append(f'  <path id="axon_hvc_c" d="M 792 316 C 872 292, 940 276, 1010 292" '
             f'fill="none" stroke="{C["hvc"]}" stroke-width="4.5" stroke-linecap="round" opacity="{hop}"{hdash}/>\n')
    # ---- LMAN: enters lower right, rises to the proximal shaft ----
    g.append(f'  <rect id="box_lman" x="1206" y="700" width="304" height="118" rx="16" '
             f'fill="{C["lman"]}" opacity="0.16" stroke="{C["lman"]}" stroke-width="3"/>\n')
    g.append(txt(1358, 750, "LMAN", 36, C["lman"], "middle", "700", ident="lbl_lman"))
    g.append(txt(1358, 784, "NMDA \u00b7 slow \u00b7 variable", 19, C["lman"], "middle", ident="lbl_lman_sub"))
    g.append(f'  <path id="axon_lman" d="M 1206 742 C 1080 738, 960 690, 880 610 '
             f'C 830 560, 800 528, 786 500" fill="none" stroke="{C["lman"]}" '
             f'stroke-width="5.5" stroke-linecap="round"/>\n')
    g.append(f'  <path id="axon_lman_b" d="M 880 610 C 800 588, 700 540, 640 452" '
             f'fill="none" stroke="{C["lman"]}" stroke-width="4.5" stroke-linecap="round"/>\n')
    g.append(f'  <path id="axon_lman_c" d="M 786 500 C 840 476, 886 442, 918 396" '
             f'fill="none" stroke="{C["lman"]}" stroke-width="4.5" stroke-linecap="round"/>\n')
    g.append('</g>\n')
    return "".join(g)


def interneuron(state="unknown"):
    """Local GABAergic interneuron, upper right. Its axon descends to the
    proximal shaft. Dashed throughout: this is what the project measures."""
    cx, cy = 1258.0, 300.0
    dash = ' stroke-dasharray="8 6"' if state == "unknown" else ""
    fill_op = 0.14 if state == "unknown" else 0.9
    g = ['<g id="interneuron">\n']
    g.append(f'  <path id="in_axon" d="M {cx-34} {cy+30} C 1160 420, 1040 520, 900 566 '
             f'C 840 586, 790 570, 772 534" fill="none" stroke="{C["inh"]}" '
             f'stroke-width="5.5" stroke-linecap="round"{dash}/>\n')
    g.append(f'  <path id="in_axon_b" d="M 1040 520 C 960 480, 880 440, 812 428" '
             f'fill="none" stroke="{C["inh"]}" stroke-width="4.5" stroke-linecap="round"{dash}/>\n')
    g.append(f'  <path id="in_axon_c" d="M 900 566 C 830 596, 760 610, 706 596" '
             f'fill="none" stroke="{C["inh"]}" stroke-width="4.5" stroke-linecap="round"{dash}/>\n')
    g.append(f'  <path id="in_dend_a" d="M {cx} {cy-44} L {cx-40} {cy-116}" fill="none" '
             f'stroke="{C["inh"]}" stroke-width="4.5" stroke-linecap="round"/>\n')
    g.append(f'  <path id="in_dend_b" d="M {cx} {cy-44} L {cx+42} {cy-108}" fill="none" '
             f'stroke="{C["inh"]}" stroke-width="4.5" stroke-linecap="round"/>\n')
    g.append(f'  <circle id="in_soma" cx="{cx}" cy="{cy}" r="46" fill="{C["inh"]}" '
             f'fill-opacity="{fill_op}" stroke="{C["inh"]}" stroke-width="4"{dash}/>\n')
    g.append(txt(cx, cy + 9, "IN", 24, C["inh"], "middle", "700", ident="lbl_in"))
    g.append('</g>\n')
    return "".join(g)


def legend():
    g = ['<g id="legend">\n']
    items = [("HVC \u00b7 AMPA \u00b7 spine", C["hvc"], "disc", False),
             ("LMAN \u00b7 NMDA \u00b7 shaft + spine", C["lman"], "disc", False),
             ("Interneuron \u00b7 shaft", C["inh"], "bar", True)]
    x0, y0 = 96, 706
    for k, (label, col, shape, dashed) in enumerate(items):
        y = y0 + k * 34
        d = ' stroke-dasharray="5 4"' if dashed else ""
        f = "none" if dashed else col
        if shape == "disc":
            g.append(f'  <circle id="leg{k}_mark" cx="{x0}" cy="{y-6}" r="10" fill="{f}" '
                     f'stroke="{col}" stroke-width="2.5"{d}/>\n')
        else:
            g.append(f'  <rect id="leg{k}_mark" x="{x0-8}" y="{y-20}" width="16" height="28" rx="4" '
                     f'fill="{f}" stroke="{col}" stroke-width="2.5"{d}/>\n')
        g.append(txt(x0 + 26, y + 1, label, 19, C["muted"], ident=f"leg{k}_label"))
    g.append(txt(x0 - 4, y0 + 3 * 34 + 6,
                 "dashed = measured by this project",
                 17, C["inh"], style="font-style:italic", ident="leg_note"))
    g.append('</g>\n')
    return "".join(g)


def gate_highlight(label="Gates LMAN input"):
    """Shaded disc over an adjacent LMAN + inhibitory pair (cf. Figure 1B)."""
    gx, gy = 744.0, 452.0
    g = ['<g id="gate_highlight">\n']
    g.append(f'  <circle id="gate_disc" cx="{gx}" cy="{gy}" r="74" fill="{C["inh"]}" '
             f'fill-opacity="0.15" stroke="{C["inh"]}" stroke-width="2.5" '
             f'stroke-dasharray="6 5"/>\n')
    g.append(f'  <path id="gate_leader" d="M {gx-70} {gy+42} L {gx-190} {gy+112}" '
             f'fill="none" stroke="{C["inh"]}" stroke-width="2"/>\n')
    g.append(txt(gx - 196, gy + 118, label, 20, C["inh"], "end", "600", ident="lbl_gate"))
    g.append('</g>\n')
    return "".join(g)


def build_timepoint(fname, cfg, gate=False, hvc_state='on'):
    sp_cfg, sh_cfg, scale, title, caption = cfg()
    s = [head(), bg_layer()]
    s.append(txt(96, 84, title, 40, C["text"], weight="700", ident="slide_title"))
    s.append(txt(96, 120, caption, 21, C["muted"], ident="slide_caption"))
    s.append(source_boxes(hvc_state))
    s.append(interneuron("unknown"))
    # dendrite + synapses scale together about the soma (RA peaks in size at 50 dph)
    sx, sy = SOMA
    s.append(f'<g id="cell_and_synapses" transform="translate({sx} {sy}) '
             f'scale({scale}) translate({-sx} {-sy})">\n')
    s.append(dendrite_group())
    s.append('<g id="synapses">\n')
    for sid, seg, t, side in SPINES:
        occ, st = sp_cfg.get(sid, (None, "on"))
        s.append(spine(sid, seg, t, side, occ, st))
    for sid, seg, t, side in SHAFTS:
        occ, st = sh_cfg.get(sid, (None, "on"))
        s.append(shaft_syn(sid, seg, t, side, occ, st))
    s.append('</g>\n</g>\n')
    if gate:
        s.append(gate_highlight())
    s.append(legend())
    s.append('</svg>\n')
    with open(os.path.join(OUT, fname), "w") as f:
        f.write("".join(s))
    print("wrote", fname)


for fn, cfg, gate, hstate in [("03_ra_p25.svg", cfg_p25, False, "ghost"),
                      ("04_ra_p50.svg", cfg_p50, False, "on"),
                      ("05_ra_p70.svg", cfg_p70, False, "on"),
                      ("06_ra_p90_adult.svg", cfg_p90, True, "on")]:
    build_timepoint(fn, cfg, gate, hstate)
