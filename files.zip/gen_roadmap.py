#!/usr/bin/env python3
"""
Roadmap (scene 2) and the four section dividers that morph out of it.

Same canvas, palette and ids as the other assets, so the divider slides are a
Morph away from the roadmap: the active card lifts and the rest recede.
"""
import os

W, H = 1600, 900
FAM = "Calibri, Carlito, Candara, sans-serif"
C = dict(
    accent="#0E7C8B", accent_soft="#E3F0F2",
    plan="#7A8496", plan_soft="#EDEFF3",
    bg="#F7F8FA", text="#1A1D26", muted="#5C6472", rule="#D3D8E0",
)
OUT = "/home/claude/svg"
os.makedirs(OUT, exist_ok=True)

SECTIONS = [
    dict(n=1, kicker="THE CIRCUIT", q="What is the question?",
         body=["RA receives precise timing from HVC",
               "and variability from LMAN.",
               "Interneurons are the untested player",
               "in that convergence."],
         chip="background", state="ctx"),
    dict(n=2, kicker="THE MODEL", q="Is inhibition necessary?",
         body=["A biophysical RA projection neuron",
               "with no inhibition. At physiological",
               "LMAN drive it loses the HVC lock,",
               "so something must suppress LMAN."],
         chip="done this year", state="done"),
    dict(n=3, kicker="THE METHOD", q="Can I measure it?",
         body=["Iterative expansion carries a full",
               "1 mm block to ~13\u00d7 linear.",
               "Labelling and segmentation are",
               "in progress."],
         chip="in progress", state="wip"),
    dict(n=4, kicker="THE PLAN", q="Will it work in a PhD?",
         body=["24 samples at 25, 50, 70, 90 dph.",
               "~145 instrument-days, ~15.7 PB.",
               "Endpoints first, so the hypothesis",
               "is tested within 18 months."],
         chip="next 18 months", state="plan"),
]


def txt(x, y, s, size=20, fill=None, anchor="start", weight="400", ident=None, style=""):
    fill = fill or C["text"]
    i = f' id="{ident}"' if ident else ""
    return (f'<text{i} x="{x}" y="{y}" font-family="{FAM}" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}" style="{style}">{s}</text>\n')


def card(sec, x, y, w, h, active):
    """active=True -> full colour. active=False -> receded but still legible."""
    lead = C["accent"] if sec["state"] in ("done", "wip") else C["plan"]
    fill = C["accent_soft"] if sec["state"] in ("done", "wip") else C["plan_soft"]
    op = 1.0 if active else 0.32
    sw = 3 if active else 1.8
    ident = f'sec{sec["n"]}'
    g = [f'<g id="{ident}" opacity="{op}">\n']
    g.append(f'  <rect id="{ident}_bg" x="{x}" y="{y}" width="{w}" height="{h}" rx="18" '
             f'fill="{fill}" stroke="{lead}" stroke-width="{sw}"/>\n')
    g.append(f'  <circle id="{ident}_badge" cx="{x+40}" cy="{y+44}" r="21" fill="{lead}"/>\n')
    g.append(txt(x + 40, y + 51, str(sec["n"]), 21, "#FFFFFF", "middle", "700",
                 ident=f"{ident}_num"))
    g.append(txt(x + 74, y + 51, sec["kicker"], 16, lead, weight="700",
                 ident=f"{ident}_kicker", style="letter-spacing:1.4px"))
    g.append(txt(x + 26, y + 118, sec["q"], 25, C["text"], weight="700", ident=f"{ident}_q"))
    g.append(f'  <line id="{ident}_rule" x1="{x+26}" y1="{y+142}" x2="{x+w-26}" y2="{y+142}" '
             f'stroke="{lead}" stroke-width="1.6" opacity="0.5"/>\n')
    for j, ln in enumerate(sec["body"]):
        g.append(txt(x + 26, y + 178 + j * 27, ln, 18, C["muted"], ident=f"{ident}_b{j}"))
    cy = y + h - 40
    g.append(f'  <rect id="{ident}_chip" x="{x+26}" y="{cy-20}" width="{len(sec["chip"])*9+30}" '
             f'height="32" rx="16" fill="{lead}" fill-opacity="0.16" stroke="{lead}" '
             f'stroke-width="1.6"/>\n')
    g.append(txt(x + 41, cy + 2, sec["chip"], 16, lead, weight="600", ident=f"{ident}_chip_t"))
    g.append('</g>\n')
    return "".join(g)


def build(active=None):
    M, GAP = 80, 26
    w = (W - 2 * M - 3 * GAP) / 4
    y, h = 250, 400
    s = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">\n',
         f'<g id="bg_slide"><rect id="bg_rect" x="0" y="0" width="{W}" height="{H}" '
         f'fill="{C["bg"]}"/></g>\n']
    title = "Four questions this talk answers" if active is None else SECTIONS[active - 1]["q"]
    s.append(txt(M, 92, title, 40, C["text"], weight="700", ident="slide_title"))
    if active is None:
        s.append(txt(M, 130,
                     "Developmental connectomics of the RA microcircuit in the zebra finch.",
                     21, C["muted"], ident="slide_caption"))
    else:
        s.append(txt(M, 130, SECTIONS[active - 1]["kicker"], 21, C["accent"], weight="700",
                     ident="slide_caption", style="letter-spacing:1.4px"))

    # spine linking the four stages
    s.append(f'  <line id="spine" x1="{M+20}" y1="{y-26}" x2="{W-M-20}" y2="{y-26}" '
             f'stroke="{C["rule"]}" stroke-width="2"/>\n')
    for i, sec in enumerate(SECTIONS):
        x = M + i * (w + GAP)
        s.append(card(sec, x, y, w, h, active is None or active == sec["n"]))
    s.append(txt(M, 726,
                 "The connectome supplies the wiring the model needs; the model says which parameters to measure first.",
                 20, C["muted"], ident="footer", style="font-style:italic"))
    s.append('</svg>\n')
    return "".join(s)


files = [("09_roadmap.svg", None)] + [
    (f"09{c}_divider_{k}.svg", k) for c, k in zip("abcd", [1, 2, 3, 4])]
for fn, act in files:
    open(os.path.join(OUT, fn), "w").write(build(act))
    print("wrote", fn)
