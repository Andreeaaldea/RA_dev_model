#!/usr/bin/env python3
"""
15  The rig, and how it was validated
16  The result: the gap between the lock ceiling and measured LMAN input
17  Limitations, as three questions with answers
"""
import os

W, H = 1600, 900
C = dict(
    acc="#0E7C8B", pub="#8A93A5", lman="#C9421C", pn="#2E3550", inh="#6B2FB5",
    ok="#1E7A4B", okbg="#E4F2EA", alert="#B3261E", alertbg="#FBE9E5",
    bg="#F7F8FA", panel="#EDEFF3", accpanel="#E3F0F2", white="#FFFFFF",
    text="#1A1D26", muted="#5C6472",
)
FAM = "Calibri, Carlito, Candara, sans-serif"
OUT = "/home/claude/svg"
os.makedirs(OUT, exist_ok=True)


def txt(x, y, s, size=20, fill=None, anchor="start", weight="400", ident=None, style=""):
    fill = fill or C["text"]
    i = f' id="{ident}"' if ident else ""
    return (f'<text{i} x="{x}" y="{y}" font-family="{FAM}" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}" style="{style}">{s}</text>\n')


def head(title, cap):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">\n'
            f'<g id="bg_slide"><rect x="0" y="0" width="{W}" height="{H}" fill="{C["bg"]}"/></g>\n'
            + txt(80, 74, title, 38, C["text"], weight="700", ident="slide_title")
            + txt(80, 108, cap, 20, C["muted"], ident="slide_caption"))


def card(x, y, w, h, col, title, fill=None):
    return (f'  <rect x="{x}" y="{y}" width="{w}" height="{h}" rx="14" '
            f'fill="{fill or C["panel"]}"/>\n'
            f'  <rect x="{x}" y="{y}" width="6" height="{h}" rx="3" fill="{col}"/>\n'
            + txt(x + 24, y + 38, title, 21, col, weight="700"))


# ------------------------------------------------------------------ 15
VALID = [
    ("AP peak (mV)",        "+48",  "44.5 ± 2.9",    True),
    ("AP half-width (ms)",  "0.13", "0.16 ± 0.01",   True),
    ("max dV/dt (V/s)",     "1106", "1288.5 ± 67.1", True),
    ("C_m (pF)",            "116",  "96.1 ± 7.4",    True),
    ("R_in (MΩ)",           "141",  "185.2 ± 15.0",  False),
    ("AP threshold (mV)",   "−49",  "−52.0 ± 1.0",   True),
    ("AHP trough (mV)",     "−58",  "−65.7 ± 0.9",   False),
]


def setup_slide():
    s = [head("A minimal rig, validated against real cells",
              "Single compartment on purpose. The question is somatic spike timing, "
              "and the cell is calibrated so conductances have the right physical effect.")]

    # ---- the cell ----
    s.append(card(80, 150, 460, 452, C["pn"], "The cell"))
    rows = [("Geometry", ["Single compartment, area-calibrated so",
                          "C_m ≈ 115.6 pF matches a reconstructed",
                          "adult RAPN (NeuroMorpho NMO_268433)"]),
            ("Channels", ["Transient Na⁺, Kv3.1, resurgent Na⁺,",
                          "Kv1, HCN, Na⁺/K⁺ leak"]),
            ("Conditions", ["NEURON 9.0.1, 40 °C, hold −0.3 nA"]),
            ("Deliberately absent", ["No inhibition. This phase asks what",
                                     "happens without it."])]
    yy = 230
    for lab, lines in rows:
        s.append(txt(104, yy, lab, 15, C["pn"], weight="700"))
        yy += 22
        for ln in lines:
            s.append(txt(104, yy, ln, 17, C["muted"]))
            yy += 23
        yy += 12

    # ---- the inputs ----
    s.append(card(570, 150, 460, 452, C["acc"], "The inputs"))
    yy = 230
    inputs = [("HVC", C["acc"], ["40 AMPA synapses, 11 nS total",
                                 "8 bursts of 4 spikes at 650 Hz",
                                 "identical on every trial"]),
              ("LMAN", C["lman"], ["2 independent NMDA axons",
                                   "Jahr–Stevens Mg²⁺ block",
                                   "Poisson at 21 Hz, differs every trial"])]
    for lab, col, lines in inputs:
        s.append(txt(594, yy, lab, 17, col, weight="700"))
        yy += 24
        for ln in lines:
            s.append(txt(594, yy, ln, 17, C["muted"]))
            yy += 23
        yy += 16
    s.append(f'  <rect x="594" y="{yy}" width="412" height="76" rx="10" fill="{C["accpanel"]}"/>\n')
    s.append(txt(614, yy + 30, "Only LMAN varies between trials,", 17, C["acc"], weight="700"))
    s.append(txt(614, yy + 54, "so all output variability comes from LMAN.", 17, C["acc"], weight="700"))

    # ---- validation ----
    s.append(card(1060, 150, 460, 452, C["ok"], "Validation · Zemel 2023, 40 °C"))
    s.append(txt(1290, 216, "model", 14, C["muted"], "middle", weight="700"))
    s.append(txt(1440, 216, "measured", 14, C["muted"], "middle", weight="700"))
    yy = 244
    for lab, mine, lit, within in VALID:
        s.append(f'  <rect x="1084" y="{yy-16}" width="412" height="30" rx="6" '
                 f'fill="{C["white"]}"/>\n')
        s.append(txt(1094, yy + 4, lab, 15, C["text"]))
        s.append(txt(1290, yy + 4, mine, 15, C["ok"] if within else C["lman"],
                     "middle", weight="700"))
        s.append(txt(1440, yy + 4, lit, 15, C["muted"], "middle"))
        yy += 36
    s.append(txt(1084, yy + 12, "Spike core within about one SD.", 16, C["ok"], weight="700"))
    s.append(txt(1084, yy + 34, "Residual ~7 mV shallow after-hyperpolarisation,", 15, C["muted"]))
    s.append(txt(1084, yy + 54, "and R_in ~20% below target. Both carried forward.", 15, C["muted"]))

    # ---- why a single compartment ----
    s.append(f'  <rect x="80" y="632" width="{W-160}" height="150" rx="14" '
             f'fill="{C["accpanel"]}"/>\n')
    s.append(txt(112, 674, "Why a single compartment", 22, C["acc"], weight="700"))
    s.append(txt(112, 708,
                 "The question in this phase is somatic spike timing, not dendritic integration. "
                 "Area-calibrating to the measured capacitance of a", 18, C["text"]))
    s.append(txt(112, 734,
                 "reconstructed cell sets the correct absolute scale, so a given synaptic conductance "
                 "has the right physical effect without needing a", 18, C["text"]))
    s.append(txt(112, 760,
                 "cable structure. Voltage dynamics were confirmed to be area-invariant. "
                 "The spatial version is the next phase, not this one.", 18, C["text"]))

    s.append(txt(80, 852, "Model code: github.com/Andreeaaldea/ra-connectome", 17, C["muted"],
                 style="font-style:italic"))
    s.append('</svg>\n')
    return "".join(s)


# ------------------------------------------------------------------ 16
def result_slide():
    s = [head("HVC drive alone is not enough",
              "The conductance at which the neuron stays locked to the HVC command, "
              "against the conductance LMAN actually delivers.")]

    ax_x, ax_y, ax_w, gmax = 150, 380, 1300, 12.0
    def px(g): return ax_x + g / gmax * ax_w
    BT, BB = ax_y - 56, ax_y + 56          # band top / bottom

    s.append(f'  <rect x="{ax_x}" y="{BT}" width="{px(3)-ax_x}" height="{BB-BT}" rx="10" '
             f'fill="{C["okbg"]}"/>\n')
    s.append(f'  <rect x="{px(3)}" y="{BT}" width="{ax_x+ax_w-px(3)}" height="{BB-BT}" rx="10" '
             f'fill="{C["alertbg"]}"/>\n')
    s.append(txt((ax_x + px(3)) / 2, ax_y - 30, "locked to HVC", 19, C["ok"], "middle", "700"))
    s.append(txt((px(3) + ax_x + ax_w) / 2, ax_y - 30, "decoupled from HVC", 19, C["alert"],
                 "middle", "700"))

    s.append(f'  <line x1="{ax_x}" y1="{ax_y}" x2="{ax_x+ax_w}" y2="{ax_y}" '
             f'stroke="{C["pub"]}" stroke-width="2"/>\n')
    for g in range(0, 13, 2):
        s.append(f'  <line x1="{px(g)}" y1="{ax_y}" x2="{px(g)}" y2="{ax_y+8}" '
                 f'stroke="{C["pub"]}" stroke-width="2"/>\n')
        s.append(txt(px(g), ax_y + 28, str(g), 16, C["muted"], "middle"))
    s.append(txt(ax_x + ax_w, ax_y + 86,
                 "total LMAN NMDA conductance (nS), at 21 Hz per axon", 18, C["muted"], "end"))

    # markers: 3 and 9.5 above the band, 5 below, so nothing stacks
    marks = [(3.0,  C["ok"],    "3 nS",   "lock ceiling", "the model holds only up to here", -1),
             (9.5,  C["alert"], "9.5 nS", "maximal",      "all fibres recruited",            -1),
             (5.0,  C["alert"], "5 nS",   "one fibre",    "measured from EPSCs in behaving birds", 1)]
    for g, col, big, small, note, side in marks:
        s.append(f'  <line x1="{px(g)}" y1="{BT}" x2="{px(g)}" y2="{BB}" '
                 f'stroke="{col}" stroke-width="4"/>\n')
        s.append(f'  <circle cx="{px(g)}" cy="{ax_y}" r="11" fill="{col}"/>\n')
        if side < 0:
            s.append(txt(px(g), ax_y - 128, big,   34, col, "middle", "700"))
            s.append(txt(px(g), ax_y - 102, small, 18, col, "middle", "600"))
            s.append(txt(px(g), ax_y - 80,  note,  15, C["muted"], "middle"))
        else:
            s.append(txt(px(g), ax_y + 122, big,   34, col, "middle", "700"))
            s.append(txt(px(g), ax_y + 148, small, 18, col, "middle", "600"))
            s.append(txt(px(g), ax_y + 170, note,  15, C["muted"], "middle"))

    # the gap, bracketed clear above the marker labels
    gy = ax_y - 170
    s.append(f'  <path d="M {px(3)} {gy+10} L {px(3)} {gy} L {px(9.5)} {gy} L {px(9.5)} {gy+10}" '
             f'fill="none" stroke="{C["alert"]}" stroke-width="2.5" stroke-dasharray="7 5"/>\n')
    s.append(txt((px(3) + px(9.5)) / 2, gy - 10,
                 "everything measured in a real bird sits in here", 17, C["alert"],
                 "middle", "600"))

    steps = [("1", "At the directed-singing rate, the un-inhibited neuron stays locked to the "
                   "HVC command only up to 3 nS."),
             ("2", "Measured LMAN input is 5 nS for a single fibre and 9.5 nS at full "
                   "recruitment."),
             ("3", "So at physiological drive the neuron fires between bursts. HVC strengthening "
                   "alone cannot produce the adult output.")]
    yy = 604
    for n, ln in steps:
        s.append(f'  <circle cx="104" cy="{yy-7}" r="17" fill="{C["pn"]}"/>\n')
        s.append(txt(104, yy, n, 18, "#FFFFFF", "middle", "700"))
        s.append(txt(136, yy, ln, 20, C["text"]))
        yy += 44

    s.append(f'  <rect x="80" y="726" width="{W-160}" height="92" rx="14" fill="{C["accpanel"]}"/>\n')
    s.append(txt(112, 766, "Something must suppress LMAN.", 25, C["acc"], weight="700"))
    s.append(txt(112, 798,
                 "Inhibition is the candidate this project tests. Whether the inhibitory wiring "
                 "is there to support it is what the connectome will show.", 19, C["text"]))
    s.append('</svg>\n')
    return "".join(s)


# ------------------------------------------------------------------ 17
LIMS = [
    (C["lman"], "Does a single compartment overstate LMAN?",
     ["All synapses sit at the soma. In a real cell the LMAN",
      "NMDA synapses are dendritic, and cable filtering would",
      "attenuate them, making it easier to stay locked to HVC."],
     "But local input impedance is higher in a dendrite, so NMDA may relieve its "
     "Mg²⁺ block more readily there. The direction is genuinely unclear, which is "
     "why the next phase moves to reconstructed morphology."),
    (C["inh"], "Required, or just sufficient?",
     ["The model shows something must reduce LMAN's effective",
      "influence. Inhibition is one candidate. Others: dendritic",
      "distance, a lower adult LMAN rate, synaptic depression,",
      "and the NR2B→NR2A switch speeding NMDA decay."],
     "Figure 5C is the awkward one: jitter crosses the adult target near Q₁₀ = 2, so "
     "faster NMDA kinetics alone could rescue timing. The claim I defend is that active "
     "suppression is required, not that it must be inhibitory."),
    (C["alert"], "Is the Mg²⁺ block counted twice?",
     ["LMAN conductance was derived from measured EPSCs by",
      "Ohm's law, then a Jahr–Stevens Mg²⁺ block was applied",
      "in the model. The measured EPSC already reflects the",
      "block present at the recording potential."],
     "If so, 5 and 9.5 nS are effective conductances and the block is applied twice, "
     "which would move the headline number. Checking the original recording voltage "
     "is the first thing on the list."),
]


def limitations_slide():
    s = [head("What this model does not settle",
              "Three things a panel should push on, and what the next phase does about each.")]
    cw = (W - 160 - 2 * 24) / 3
    for k, (col, q, body, ans) in enumerate(LIMS):
        x = 80 + k * (cw + 24)
        s.append(card(x, 150, cw, 400, col, ""))
        yy = 196
        for ln in _wrap(q, 30):
            s.append(txt(x + 24, yy, ln, 22, col, weight="700"))
            yy += 28
        yy += 14
        for ln in body:
            s.append(txt(x + 24, yy, ln, 16, C["muted"]))
            yy += 23
        yy += 16
        s.append(f'  <line x1="{x+24}" y1="{yy-10}" x2="{x+cw-24}" y2="{yy-10}" '
                 f'stroke="{C["pub"]}" stroke-width="1" opacity="0.5"/>\n')
        yy += 18
        for ln in _wrap(ans, 44):
            s.append(txt(x + 24, yy, ln, 16, C["text"]))
            yy += 23

    s.append(f'  <rect x="80" y="588" width="{W-160}" height="152" rx="14" fill="{C["accpanel"]}"/>\n')
    s.append(txt(112, 630, "What the next phase does", 22, C["acc"], weight="700"))
    nxt = ["Move to reconstructed projection-neuron morphology, so inhibition can be placed "
           "at a real cable distance from LMAN input.",
           "Add reconstructed interneurons with inhibitory synapses at measured locations, "
           "and compare juvenile against adult architecture.",
           "Virtual lesions of interneuron→projection-neuron connections, and sweeps of the "
           "HVC:LMAN ratio onto interneurons, ranked by sensitivity."]
    yy = 664
    for ln in nxt:
        s.append(f'  <circle cx="120" cy="{yy-6}" r="4" fill="{C["acc"]}"/>\n')
        s.append(txt(136, yy, ln, 18, C["text"]))
        yy += 26
    s.append(txt(80, 790,
                 "The model is limited by design in this phase: no inhibition, and no space. "
                 "Both are the point of the next one.",
                 17, C["muted"], style="font-style:italic"))
    s.append('</svg>\n')
    return "".join(s)


def _wrap(t, n):
    out, line = [], ""
    for w in t.split():
        trial = (line + " " + w).strip()
        if len(trial) <= n:
            line = trial
        else:
            out.append(line); line = w
    if line:
        out.append(line)
    return out


for fn, content in [("15_model_setup.svg", setup_slide()),
                    ("16_model_result.svg", result_slide()),
                    ("17_model_limitations.svg", limitations_slide())]:
    open(os.path.join(OUT, fn), "w").write(content)
    print("wrote", fn)
