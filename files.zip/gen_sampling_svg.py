#!/usr/bin/env python3
"""
14  Sampling design: how many animals, how many neurons, what counts as a
    reconstruction. Includes the variance-vs-cells curve that justifies k ~ 10.
"""
import math, os

W, H = 1600, 900
C = dict(
    acc="#0E7C8B", pub="#8A93A5", warm="#C9421C", inh="#6B2FB5",
    bg="#F7F8FA", panel="#EDEFF3", accpanel="#E3F0F2",
    text="#1A1D26", muted="#5C6472",
)
FAM = "Calibri, Carlito, Candara, sans-serif"
OUT = "/home/claude/svg"
os.makedirs(OUT, exist_ok=True)


def txt(x, y, s, size=20, fill=None, anchor="start", weight="400", ident=None, style=""):
    fill = fill or C["text"]
    i = f' id="{ident}"' if ident else ""
    return (f'<text{i} x="{x}" y="{y}" font-family="{FAM}" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}" style="{style}">{s}</text>\n')


def card(x, y, w, h, col, title):
    return (f'  <rect x="{x}" y="{y}" width="{w}" height="{h}" rx="14" fill="{C["panel"]}"/>\n'
            f'  <rect x="{x}" y="{y}" width="6" height="{h}" rx="3" fill="{col}"/>\n'
            + txt(x + 24, y + 38, title, 21, col, weight="700"))


def variance_curve(x, y, w, h):
    """Relative SE against cells reconstructed per animal, when within- and
    between-animal variance are comparable. Shows where the returns stop."""
    g = [f'<g id="curve">\n']
    ks = list(range(1, 21))
    vals = [math.sqrt(1 + 1.0 / k) for k in ks]
    vmin, vmax = 1.0, 1.45
    def px(k): return x + (k - 1) / 19 * w
    def py(v): return y + h - (v - vmin) / (vmax - vmin) * h
    # axes
    g.append(f'  <line x1="{x}" y1="{y+h}" x2="{x+w}" y2="{y+h}" stroke="{C["pub"]}" stroke-width="1.5"/>\n')
    g.append(f'  <line x1="{x}" y1="{y}" x2="{x}" y2="{y+h}" stroke="{C["pub"]}" stroke-width="1.5"/>\n')
    # asymptote
    g.append(f'  <line x1="{x}" y1="{py(1.0)}" x2="{x+w}" y2="{py(1.0)}" stroke="{C["pub"]}" '
             f'stroke-width="1.5" stroke-dasharray="6 5"/>\n')
    g.append(txt(x + w - 4, py(1.0) + 22, "no further gain beyond this line", 14, C["muted"], "end"))
    # curve
    d = " ".join(("M" if i == 0 else "L") + f" {px(k):.1f} {py(v):.1f}"
                 for i, (k, v) in enumerate(zip(ks, vals)))
    g.append(f'  <path d="{d}" fill="none" stroke="{C["acc"]}" stroke-width="3.5" '
             f'stroke-linecap="round" stroke-linejoin="round"/>\n')
    # marker at k = 10
    g.append(f'  <line x1="{px(10)}" y1="{py(vals[9])}" x2="{px(10)}" y2="{y+h}" '
             f'stroke="{C["acc"]}" stroke-width="1.5" stroke-dasharray="4 4"/>\n')
    g.append(f'  <circle cx="{px(10)}" cy="{py(vals[9])}" r="7" fill="{C["acc"]}"/>\n')
    g.append(txt(px(10) + 14, py(vals[9]) - 16, "10 cells: within 5%", 15, C["acc"], weight="700"))
    for k in (1, 5, 10, 15, 20):
        g.append(txt(px(k), y + h + 44, str(k), 14, C["muted"], "middle"))
    g.append(txt(x + w / 2, y + h + 68, "cells reconstructed per animal", 15, C["muted"], "middle"))
    g.append(txt(x - 8, y + 10, "1.41\u00d7", 14, C["muted"], "end"))
    g.append(txt(x - 8, y + h, "1.00\u00d7", 14, C["muted"], "end"))
    g.append('</g>\n')
    return "".join(g)


def sampling():
    s = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">\n',
         f'<g id="bg_slide"><rect x="0" y="0" width="{W}" height="{H}" fill="{C["bg"]}"/></g>\n']
    s.append(txt(80, 74, "How much do I actually need to reconstruct?", 38, C["text"],
                 weight="700", ident="slide_title"))
    s.append(txt(80, 108,
                 "The comparison is between animals, so animals are the unit that counts. "
                 "Cells per animal hit diminishing returns fast.",
                 20, C["muted"], ident="slide_caption"))

    # ---- animals ----
    s.append(card(80, 150, 460, 300, C["acc"], "Animals: 6 per timepoint"))
    lines = [("", "24 animals across 25, 50, 70 and 90 dph."),
             ("Power", "80% for a difference of ~1.6 SD between"),
             ("", "timepoints, ~1.5 SD for a trend across all four."),
             ("", "These are large effects, and no prior variance"),
             ("", "estimate exists for these quantities in RA."),
             ("Also set by", "attrition in the pipeline, and 145 instrument-"),
             ("", "days of imaging for 24 samples.")]
    yy = 208
    for lab, ln in lines:
        if lab:
            s.append(txt(104, yy, lab, 15, C["acc"], weight="700"))
            yy += 20
        s.append(txt(104, yy, ln, 17, C["muted"]))
        yy += 24
    s.append(f'  <rect x="104" y="396" width="412" height="38" rx="8" fill="{C["accpanel"]}"/>\n')
    s.append(txt(118, 421, "90 and 25 dph first: an internal pilot for variance", 17, C["acc"],
                 weight="700"))

    # ---- cells ----
    s.append(card(570, 150, 460, 300, C["acc"], "Cells: about 10 per type"))
    s.append(variance_curve(614, 220, 372, 130))

    # ---- what counts as a reconstruction ----
    s.append(card(1060, 150, 460, 300, C["inh"], "What a reconstruction means"))
    tiers = [("Segments", "150 to 200 \u00b5m of dendrite, ~10 PN and", "~10 IN per animal"),
             ("Complete cells", "2 to 3 of each type per animal, for total", "counts, IN\u2192PN wiring and the model"),
             ("Not needed", "the full RA volume is imaged, but not", "densely proofread")]
    yy = 208
    for t, l1, l2 in tiers:
        s.append(txt(1084, yy, t, 16, C["inh"], weight="700"))
        s.append(txt(1084, yy + 22, l1, 17, C["muted"]))
        s.append(txt(1084, yy + 44, l2, 17, C["muted"]))
        yy += 82

    # ---- why segments are enough ----
    s.append(f'  <rect x="80" y="488" width="{W-160}" height="188" rx="14" fill="{C["panel"]}"/>\n')
    s.append(txt(104, 526, "Why sampled segments answer the predictions", 22, C["text"],
                 weight="700", ident="why_h"))
    preds = [("Prediction 1", "the LMAN:HVC ratio falls further on interneurons than on projection neurons",
              "a ratio per unit dendrite: satisfied by sampled segments"),
             ("Prediction 2", "inhibitory synapses lie close in cable distance to LMAN inputs",
              "a within-dendrite spatial statistic: satisfied by connected segments"),
             ("Prediction 3", "these features emerge before or with crystallisation",
              "the same measures repeated across the four timepoints")]
    yy = 562
    for a, b, c in preds:
        s.append(txt(104, yy, a, 17, C["acc"], weight="700"))
        s.append(txt(226, yy, b, 17, C["text"]))
        s.append(txt(880, yy, c, 17, C["muted"], style="font-style:italic"))
        yy += 36

    # ---- totals ----
    s.append(f'  <rect x="80" y="700" width="{W-160}" height="96" rx="14" fill="{C["accpanel"]}"/>\n')
    tot = [("24", "animals"), ("~480", "segment-level cells"), ("~120", "complete cells"),
           ("145 d", "imaging"), ("15.7 PB", "raw data")]
    tw = (W - 160) / len(tot)
    for i, (n, lab) in enumerate(tot):
        cx = 80 + i * tw + tw / 2
        s.append(txt(cx, 748, n, 32, C["acc"], "middle", "700", ident=f"tot{i}_n"))
        s.append(txt(cx, 776, lab, 17, C["muted"], "middle", ident=f"tot{i}_l"))

    s.append(txt(80, 852,
                 "Reconstruction effort is the number to sanity-check: proofreading hours per cell "
                 "\u00d7 cells, not imaging days.",
                 18, C["muted"], ident="footer", style="font-style:italic"))
    s.append('</svg>\n')
    return "".join(s)


open(os.path.join(OUT, "14_sampling_design.svg"), "w").write(sampling())
print("wrote 14_sampling_design.svg")
