#!/usr/bin/env python3
"""
09  Protocol comparison: the report protocol vs the new chemistry with Sven
10  Full recipes, backup slide
"""
import os

W, H = 1600, 900
C = dict(
    acc="#0E7C8B", pub="#8A93A5", warm="#C9421C", inh="#6B2FB5",
    bg="#F7F8FA", panel="#EDEFF3", accpanel="#E3F0F2",
    text="#1A1D26", muted="#5C6472",
)
FAM = "Calibri, Carlito, Candara, sans-serif"
OUT = "/home/claude/svg"
os.makedirs(OUT, exist_ok=True)


def txt(x, y, s, size=20, fill=None, anchor="start", weight="400", ident=None, style=""):
    fill = fill or C["text"]
    i = f' id="{ident}"' if ident else ""
    return (f'<text{i} x="{x}" y="{y}" font-family="{FAM}" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}" style="{style}">{s}</text>\n')


def wrap(text, width):
    """Break on spaces, never mid-word."""
    out, line = [], ""
    for word in text.split():
        trial = (line + " " + word).strip()
        if len(trial) <= width:
            line = trial
        else:
            out.append(line)
            line = word
    if line:
        out.append(line)
    return out


def head():
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">\n'
            f'<g id="bg_slide"><rect x="0" y="0" width="{W}" height="{H}" fill="{C["bg"]}"/></g>\n')


# ---------------------------------------------------------------- 09
ROWS = [
    ("Anchoring",        "Epoxide, after clearing",        "GMA + TGE, before clearing",             True),
    ("Clearing",         "iDISCO",                          "iDISCO, unchanged",                      False),
    ("First gel",        "LICONN monomer",                  "pan-ExM-t monomer, TEMPO activation",    True),
    ("Homogenisation",   "100 min at 95 \u00b0C",           "4 h thin / >12 h at 1 mm, 92 \u00b0C",   True),
    ("Stabilising gel",  "LICONN cleavable gel",            "pan-ExM-t monomer, 10% AAm + 0.1% DATD", True),
    ("Second gel",       "LICONN monomer",                  "MAGNIFY monomer with DMAA",              True),
    ("Cleavage",         "LICONN",                          "Sodium metaperiodate, pH 5",             True),
    ("Slicing",          "500 \u00b5m, partially expanded", "1 mm, expand fully then shrink",         True),
    ("Expansion factor", "~13\u00d7",                       "~20\u00d7 in the latest cohort",         True),
    ("Labelling",        "DiI; pan-protein poor in gel",    "pan-protein much improved",              True),
]

CHIPS = [
    ("Why TEMPO",
     ["TEMPO slows polymerisation, so the initiators can stay",
      "at working strength (0.2% APS and TEMED) instead of",
      "dropping to pan-ExM-t's 0.05%."]),
    ("Why longer and cooler",
     ["92 \u00b0C for 4 h, or over 12 h at 1 mm, rather than",
      "100 min at 95 \u00b0C. A first attempt at suppressing",
      "folding from retained protein and lipid."]),
    ("Why the MAGNIFY second gel",
     ["Two reasons: a higher expansion factor, and better",
      "probe access for antibodies through the gel."]),
]


def comparison():
    s = [head()]
    s.append(txt(80, 74, "Where the protocol is going", 38, C["text"], weight="700",
                 ident="slide_title"))
    s.append(txt(80, 108,
                 "Same architecture, new gel chemistry. In development with Sven Truckenbrodt.",
                 20, C["muted"], ident="slide_caption"))

    x0, x1, x2 = 80, 430, 970
    w1, w2 = 510, 550
    yh = 168
    s.append(txt(x0, yh, "STAGE", 16, C["muted"], weight="700", ident="h_stage"))
    s.append(txt(x1, yh, "IN THE FIRST-YEAR REPORT", 16, C["pub"], weight="700", ident="h_old"))
    s.append(txt(x2, yh, "NOW, IN DEVELOPMENT", 16, C["acc"], weight="700", ident="h_new"))
    s.append(f'  <line x1="{x0}" y1="{yh+12}" x2="{W-80}" y2="{yh+12}" stroke="{C["pub"]}" '
             f'stroke-width="1.5" opacity="0.6"/>\n')

    rh = 44
    for i, (stage, old, new, changed) in enumerate(ROWS):
        y = yh + 34 + i * rh
        if i % 2 == 0:
            s.append(f'  <rect x="{x0-12}" y="{y-24}" width="{W-160+24}" height="{rh}" rx="8" '
                     f'fill="{C["panel"]}" opacity="0.55"/>\n')
        if changed:
            s.append(f'  <rect id="hl{i}" x="{x2-14}" y="{y-24}" width="{w2+16}" height="{rh}" rx="8" '
                     f'fill="{C["accpanel"]}"/>\n')
        s.append(txt(x0, y, stage, 19, C["text"], weight="700", ident=f"r{i}_stage"))
        s.append(txt(x1, y, old, 19, C["muted"], ident=f"r{i}_old"))
        s.append(txt(x2, y, new, 19, C["acc"] if changed else C["muted"],
                     weight="600" if changed else "400", ident=f"r{i}_new"))

    cy = yh + 34 + len(ROWS) * rh + 22
    cw = (W - 160 - 2 * 24) / 3
    for k, (t, body) in enumerate(CHIPS):
        x = 80 + k * (cw + 24)
        s.append(f'  <rect id="chip{k}" x="{x}" y="{cy}" width="{cw}" height="112" rx="12" '
                 f'fill="{C["panel"]}"/>\n')
        s.append(txt(x + 20, cy + 32, t, 19, C["acc"], weight="700", ident=f"chip{k}_h"))
        for j, ln in enumerate(body):
            s.append(txt(x + 20, cy + 58 + j * 22, ln, 16, C["muted"], ident=f"chip{k}_b{j}"))

    s.append(txt(80, 872,
                 "Immunolabelling sits after re-slicing, and is being validated on the new chemistry. Pan-protein labelling is already much better.",
                 19, C["text"], ident="footer"))
    s.append('</svg>\n')
    return "".join(s)


# ---------------------------------------------------------------- 10
CARDS = [
    ("First expandable gel", "adapted from pan-ExM-t",
     [("Monomer", "34% sodium acrylate \u00b7 10% acrylamide \u00b7 0.2% DATD"),
      ("Activation", "0.001% TEMPO \u00b7 0.2% APS \u00b7 0.2% TEMED"),
      ("Note", "activation from MAGNIFY, not pan-ExM-t")],
     "TEMPO lets the initiators stay at 0.2% rather than dropping to 0.05%"),
    ("Homogenisation", "buffer from LICONN",
     [("Buffer", "LICONN, pH 9, no urea"),
      ("This work", "92 \u00b0C \u00b7 4 h thin gels \u00b7 >12 h for 1 mm gels"),
      ("For comparison", "LICONN 100 min at 95 \u00b0C \u00b7 pan-ExM-t 4 h at 75 \u00b0C")],
     "longer and cooler, to suppress folding from retained protein and lipid"),
    ("Stabilising gel", "monomer from pan-ExM-t",
     [("Monomer", "10% acrylamide \u00b7 0.1% DATD"),
      ("Activation", "standard MAGNIFY stabilisation"),
      ("Note", "not pan-ExM-t's lower 0.05% TEMED / APS")],
     "polymerised, then washed in PBS before the second gel"),
    ("Second expandable gel", "adapted from MAGNIFY",
     [("Monomer", "34% sodium acrylate \u00b7 10% acrylamide"),
      ("", "4% DMAA \u00b7 0.01% bis-acrylamide"),
      ("Activation", "0.001% TEMPO \u00b7 0.2% APS \u00b7 0.2% TEMED")],
     "chosen for higher expansion factor and better probe access"),
    ("Cleavage", "DATD",
     [("Reagent", "sodium metaperiodate, pH 5"),
      ("Washes", "NH\u2084Cl, then PBS"),
      ("Then", "expand in water")],
     "cleaves the DATD crosslinker in the stabilising gel"),
    ("Expansion and slicing", "",
     [("1", "full expansion in water, whole gel"),
      ("2", "shrink back in PBS, slice at 1 mm"),
      ("3", "re-expand to final factor, ~20\u00d7 in the latest cohort")],
     "then pan-protein staining, and immunolabelling still to be finalised"),
]


def chemistry():
    s = [head()]
    s.append(txt(80, 74, "New gel chemistry, in detail", 38, C["text"], weight="700",
                 ident="slide_title"))
    s.append(txt(80, 108, "Backup slide. Recipes as currently run.", 20, C["muted"],
                 ident="slide_caption"))
    cw, chh = (W - 160 - 2 * 26) / 3, 320
    for k, (title, source, rows, note) in enumerate(CARDS):
        col, row = k % 3, k // 3
        x = 80 + col * (cw + 26)
        y = 150 + row * (chh + 26)
        s.append(f'<g id="card{k}">\n')
        s.append(f'  <rect x="{x}" y="{y}" width="{cw}" height="{chh}" rx="14" '
                 f'fill="{C["panel"]}"/>\n')
        s.append(f'  <rect x="{x}" y="{y}" width="6" height="{chh}" rx="3" fill="{C["acc"]}"/>\n')
        s.append(txt(x + 24, y + 40, title, 21, C["text"], weight="700", ident=f"c{k}_t"))
        if source:
            s.append(txt(x + 24, y + 66, source, 16, C["acc"], ident=f"c{k}_s",
                         style="font-style:italic"))
        yy = y + 104
        for j, (lab, val) in enumerate(rows):
            if lab:
                s.append(txt(x + 24, yy, lab, 15, C["muted"], weight="700", ident=f"c{k}_l{j}"))
                yy += 21
            s.append(txt(x + 24, yy, val, 16, C["text"], ident=f"c{k}_v{j}"))
            yy += 28
        s.append(f'  <line x1="{x+24}" y1="{y+chh-58}" x2="{x+cw-24}" y2="{y+chh-58}" '
                 f'stroke="{C["pub"]}" stroke-width="1" opacity="0.5"/>\n')
        for j, ln in enumerate(wrap(note, 54)[:2]):
            s.append(txt(x + 24, y + chh - 36 + j * 20, ln, 15, C["muted"],
                         ident=f"c{k}_n{j}", style="font-style:italic"))
        s.append('</g>\n')
    s.append('</svg>\n')
    return "".join(s)


for fn, content in [("09_protocol_comparison.svg", comparison()),
                    ("10_gel_chemistry_backup.svg", chemistry())]:
    open(os.path.join(OUT, fn), "w").write(content)
    print("wrote", fn)
