#!/usr/bin/env python3
"""
11  Same label, two gel chemistries (image comparison template)
12  Expansion factor measured directly from the sliced gel

Image slots are dashed placeholders. Replace each with the real image in
Illustrator or PowerPoint; the slot ids tell you which goes where.
"""
import os

W, H = 1600, 900
C = dict(
    acc="#0E7C8B", pub="#8A93A5", warm="#C9421C",
    bg="#F7F8FA", panel="#EDEFF3", accpanel="#E3F0F2", slot="#E4E7ED",
    text="#1A1D26", muted="#5C6472",
)
FAM = "Calibri, Carlito, Candara, sans-serif"
OUT = "/home/claude/svg"
os.makedirs(OUT, exist_ok=True)


def txt(x, y, s, size=20, fill=None, anchor="start", weight="400", ident=None, style=""):
    fill = fill or C["text"]
    i = f' id="{ident}"' if ident else ""
    return (f'<text{i} x="{x}" y="{y}" font-family="{FAM}" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}" style="{style}">{s}</text>\n')


def head():
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">\n'
            f'<g id="bg_slide"><rect x="0" y="0" width="{W}" height="{H}" fill="{C["bg"]}"/></g>\n')


def slot(ident, x, y, w, h, label, col=None):
    col = col or C["pub"]
    g = [f'<g id="{ident}">\n']
    g.append(f'  <rect id="{ident}_rect" x="{x}" y="{y}" width="{w}" height="{h}" rx="10" '
             f'fill="{C["slot"]}" stroke="{col}" stroke-width="2" stroke-dasharray="9 7"/>\n')
    g.append(txt(x + w / 2, y + h / 2 - 4, label, 18, C["muted"], "middle", "600",
                 ident=f"{ident}_lbl"))
    g.append(txt(x + w / 2, y + h / 2 + 22, "replace with image", 15, C["muted"], "middle",
                 ident=f"{ident}_hint", style="font-style:italic"))
    g.append('</g>\n')
    return "".join(g)


# ------------------------------------------------------------------ 11
def labelling_comparison():
    s = [head()]
    s.append(txt(80, 74, "Same label, two gel chemistries", 38, C["text"], weight="700",
                 ident="slide_title"))
    s.append(txt(80, 108,
                 "Identical labelling on both samples, so any difference is the gel and not the stain.",
                 20, C["muted"], ident="slide_caption"))

    cols = [("cA", 80, "iDISCO + LICONN", "as in the first-year report", C["pub"],
             ["Pan-protein labelling is weak in the gel",
              "DiI used as the morphology proxy",
              "~13\u00d7 linear"]),
            ("cB", 820, "New chemistry", "pan-ExM-t + MAGNIFY hybrid, with Sven", C["acc"],
             ["Pan-protein labelling much improved",
              "Better probe access through the gel",
              "~20\u00d7 linear in the latest cohort"])]
    cw = 700
    for ident, x, name, sub, col, bullets in cols:
        s.append(f'  <rect id="{ident}_hdr" x="{x}" y="158" width="{cw}" height="54" rx="10" '
                 f'fill="{C["accpanel"] if col == C["acc"] else C["panel"]}"/>\n')
        s.append(txt(x + 20, 194, name, 23, col, weight="700", ident=f"{ident}_name"))
        s.append(txt(x + cw - 20, 193, sub, 17, C["muted"], "end", ident=f"{ident}_sub"))
        s.append(slot(f"{ident}_img", x, 226, cw, 396,
                      "overview and zoom, matched scale bars", col))
        for j, b in enumerate(bullets):
            y = 664 + j * 30
            s.append(f'  <circle cx="{x+8}" cy="{y-6}" r="4" fill="{col}"/>\n')
            s.append(txt(x + 24, y, b, 19, C["text"] if col == C["acc"] else C["muted"],
                         ident=f"{ident}_b{j}"))

    s.append(f'  <rect x="80" y="782" width="{W-160}" height="60" rx="12" fill="{C["accpanel"]}"/>\n')
    s.append(txt(104, 812, "The controlled comparison is the point:", 19, C["acc"], weight="700",
                 ident="foot_h"))
    s.append(txt(104, 812 + 0, "", 19, C["muted"], ident="foot_pad"))
    s.append(txt(430, 812,
                 "same tissue type, same label, same imaging. Only the gel chemistry differs.",
                 19, C["text"], ident="foot_b"))
    s.append('</svg>\n')
    return "".join(s)


# ------------------------------------------------------------------ 12
def expansion_factor():
    s = [head()]
    s.append(txt(80, 74, "Expansion factor, measured directly", 38, C["text"], weight="700",
                 ident="slide_title"))
    s.append(txt(80, 108,
                 "The gel held together well enough to be cut along the original 1 mm axis and measured end to end.",
                 20, C["muted"], ident="slide_caption"))

    s.append(slot("gel_img", 80, 168, 700, 496,
                  "vertical slice through the expanded gel, with ruler", C["acc"]))
    s.append(txt(80, 696, "The 1 mm axis, before and after. Cut vertically so the full "
                          "expanded thickness is visible.", 18, C["muted"], ident="img_cap"))

    x = 840
    s.append(f'  <rect x="{x}" y="168" width="{W-x-80}" height="188" rx="14" '
             f'fill="{C["accpanel"]}"/>\n')
    s.append(txt(x + 32, 224, "1 mm", 46, C["muted"], weight="700", ident="ef_before"))
    s.append(txt(x + 150, 224, "\u2192", 40, C["acc"], weight="700", ident="ef_arrow"))
    s.append(txt(x + 210, 224, "~2 cm", 46, C["acc"], weight="700", ident="ef_after"))
    s.append(txt(x + 32, 268, "20 mm / 1 mm  \u2248  20\u00d7 linear", 24, C["text"],
                 weight="600", ident="ef_math"))
    s.append(txt(x + 32, 310,
                 "Measured on the axis that was actually 1 mm, which is the", 17, C["muted"],
                 ident="ef_n0"))
    s.append(txt(x + 32, 332,
                 "axis the vibratome set.", 17, C["muted"], ident="ef_n1"))

    blocks = [("Why this is better evidence",
               ["The report estimate came from nucleolar diameter in gel",
                "against a published biological value, giving ~13\u00d7 with a",
                "wide range of roughly 11 to 17\u00d7. This is a direct",
                "macroscopic measurement of a known starting dimension."]),
              ("What still needs checking",
               ["Gel expansion is not automatically tissue expansion. Confirm",
                "with an internal biological reference in the same sample.",
                "Vibratome thickness has its own tolerance, so 1 mm is nominal.",
                "State whether ~20\u00d7 is one gel or reproduced across the cohort."])]
    yy = 392
    for k, (t, lines) in enumerate(blocks):
        s.append(f'  <rect x="{x}" y="{yy}" width="{W-x-80}" height="{34+len(lines)*24+22}" '
                 f'rx="12" fill="{C["panel"]}"/>\n')
        s.append(txt(x + 32, yy + 34, t, 20,
                     C["acc"] if k == 0 else C["warm"], weight="700", ident=f"blk{k}_h"))
        for j, ln in enumerate(lines):
            s.append(txt(x + 32, yy + 62 + j * 24, ln, 16, C["muted"], ident=f"blk{k}_l{j}"))
        yy += 34 + len(lines) * 24 + 22 + 22

    s.append('</svg>\n')
    return "".join(s)



# ------------------------------------------------------------------ 13
def segmentation():
    s = [head()]
    s.append(txt(80, 74, "Better labelling, better segmentation", 38, C["text"], weight="700",
                 ident="slide_title"))
    s.append(txt(80, 108,
                 "The published LICONN model and checkpoint, run unchanged on both gel chemistries.",
                 20, C["muted"], ident="slide_caption"))

    # method strip
    s.append(f'  <rect x="80" y="140" width="{W-160}" height="48" rx="10" fill="{C["panel"]}"/>\n')
    s.append(txt(104, 171, "Same model \u00b7 same checkpoint \u00b7 no retraining \u00b7 "
                           "the only difference between the two runs is the sample.",
                 19, C["text"], ident="method_strip"))

    cols = [("sA", 80, "iDISCO + LICONN gel", "as in the report", C["pub"]),
            ("sB", 820, "New chemistry", "pan-ExM-t + MAGNIFY hybrid", C["acc"])]
    cw = 700
    for ident, x, name, sub, col in cols:
        s.append(txt(x, 226, name, 22, col, weight="700", ident=f"{ident}_name"))
        s.append(txt(x + cw, 226, sub, 17, C["muted"], "end", ident=f"{ident}_sub"))
        s.append(slot(f"{ident}_img", x, 244, cw, 300, "segmentation output", col))
        s.append(txt(x, 574, "metric:  [state it here]", 18, C["warm"], weight="600",
                     ident=f"{ident}_metric"))

    blocks = [
        (C["acc"], "The comparison runs against the new chemistry",
         ["The checkpoint was trained on LICONN gels, so the model is",
          "on home ground with the old sample and out of domain with",
          "the new one. It still segments the new gels better. The",
          "domain shift makes the result stronger, not weaker."]),
        (C["warm"], "The confound to close off",
         ["The new gels are ~20\u00d7 against ~13\u00d7, so effective resolution",
          "differs as well as the chemistry. Match effective voxel size,",
          "by downsampling the 20\u00d7 data, before attributing the gain",
          "to labelling rather than to expansion factor."]),
        (C["pub"], "Where this is going",
         ["Generating ground-truth training data from this tissue to",
          "fine-tune the model, rather than relying on the published",
          "checkpoint. Zero-shot performance is the baseline this will",
          "be measured against."]),
    ]
    bw = (W - 160 - 2 * 24) / 3
    for k, (col, t, lines) in enumerate(blocks):
        x = 80 + k * (bw + 24)
        s.append(f'  <rect x="{x}" y="612" width="{bw}" height="196" rx="12" fill="{C["panel"]}"/>\n')
        s.append(f'  <rect x="{x}" y="612" width="6" height="196" rx="3" fill="{col}"/>\n')
        s.append(txt(x + 24, 648, t, 19, col, weight="700", ident=f"sb{k}_h"))
        for j, ln in enumerate(lines):
            s.append(txt(x + 24, 682 + j * 24, ln, 16, C["muted"], ident=f"sb{k}_l{j}"))

    s.append(txt(80, 856,
                 "Segmentation with Julia. Model and checkpoint from the LICONN article.",
                 18, C["muted"], ident="footer", style="font-style:italic"))
    s.append('</svg>\n')
    return "".join(s)


for fn, content in [("11_labelling_comparison.svg", labelling_comparison()),
                    ("12_expansion_factor.svg", expansion_factor()),
                    ("13_segmentation.svg", segmentation())]:
    open(os.path.join(OUT, fn), "w").write(content)
    print("wrote", fn)
