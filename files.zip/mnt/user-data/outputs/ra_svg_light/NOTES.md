# Viva assets, light theme, Calibri

## Fixes in this pass
1. **Shaft contacts no longer land on spines.** Sites now alternate spine,
   shaft, spine, shaft along every dendritic segment at a fixed 16 px pitch,
   and adjacent spine and shaft sites are placed on opposite sides of the
   dendrite. A shaft contact cannot coincide with a spine by construction.
2. **Axons reach their boutons.** Each input now has a real axonal arbor: a
   backbone that parallels the dendritic tree at a fixed offset (HVC +34,
   LMAN -34, interneuron -60), trimmed to only the branches it actually
   supplies, plus a terminal stalk from that backbone to every single bouton.
   Nothing floats. Because the backbone is trimmed, the arbor visibly thins as
   synapses are pruned: compare the LMAN arbor at 25 dph with 90 dph.
3. **Calibri throughout**, with Carlito and Candara as fallbacks.
4. **Light theme** is now the default for every file. The dark set is in
   `dark/` if you want it back for the microscopy slides.

## A note on the PNG previews
The previews were rasterised on a machine without Calibri installed, so they
show a substitute face. The SVGs specify Calibri and will render correctly in
Illustrator and PowerPoint on your machine.

## Files
- `01_song_system_motor.svg`  scene 4 build 1
- `02_song_system_full.svg`   scene 4 build 2 (Morph from 01)
- `03_ra_p25.svg` ... `06_ra_p90.svg`  developmental series
- `07_dendrite_zoom.svg`      scene 7

## Regenerating
`gen_ra_v2.py` makes 03 to 06 (both themes). `gen_scene_svgs.py` makes 01, 02
and 07. Palette lives in `THEMES`; synapse counts live in `COUNTS`; the font
is the `FAM` constant in both files.
