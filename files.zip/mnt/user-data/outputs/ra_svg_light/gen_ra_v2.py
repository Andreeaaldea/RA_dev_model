#!/usr/bin/env python3
"""
RA microcircuit across development, v2.

Changes from v1:
  * light theme by default (dark still available via THEMES)
  * the dendritic arbor is IDENTICAL at every timepoint - no scaling.
    RA grows in connection number, not in the size of a single neuron.
  * synapse counts follow the literature:
      HVC   rises to a peak then prunes   (Garst-Orozco 2014)
      LMAN  declines monotonically         (Herrmann & Arnold 1991)
      IN    dense then pruned, but the actual numbers are UNKNOWN
            (Miller 2017 shows pruning; counts in RA are what this project measures)
    Total synapse count peaks at 50 dph, consistent with neuropil synapse
    density rising slightly between 28 and 56 dph then staying flat.
  * a counts panel makes the ratio explicit rather than leaving it to be eyeballed
"""
import math, os, random

W, H = 1600, 900

THEMES = {
    "light": dict(
        hvc="#0E7C8B", hvc_dim="#A9CFD6",
        lman="#C9421C", lman_dim="#EEC0B2",
        inh="#6B2FB5",
        pn="#2E3550", pn_stroke="#2E3550",
        bg="#F7F8FA", panel="#ECEEF3",
        text="#1A1D26", muted="#5C6472",
        dend="#98A1B3",
    ),
    "dark": dict(
        hvc="#1B9AAA", hvc_dim="#164E57",
        lman="#E4572E", lman_dim="#5C2A1B",
        inh="#8B4FD8",
        pn="#1E2438", pn_stroke="#A9B4D6",
        bg="#101319", panel="#191D26",
        text="#E6E8EC", muted="#7C8598",
        dend="#C3CBE0",
    ),
}
FAM = "Calibri, Carlito, Candara, sans-serif"

SOMA = (470.0, 706.0)
SEG = {
    "trunk": ((470, 656), (470, 494)),
    "L1":    ((470, 494), (302, 386)),
    "L2":    ((302, 386), (162, 268)),
    "L3":    ((302, 386), (322, 226)),
    "R1":    ((470, 494), (650, 396)),
    "R2":    ((650, 396), (626, 236)),
    "R3":    ((650, 396), (806, 292)),
}
SEG_W = {"trunk": 17, "L1": 12, "R1": 12, "L2": 7.5, "L3": 7.5, "R2": 7.5, "R3": 7.5}


def pt(seg, t):
    (x1, y1), (x2, y2) = SEG[seg]
    return (x1 + (x2 - x1) * t, y1 + (y2 - y1) * t)


def nrm(seg, side):
    (x1, y1), (x2, y2) = SEG[seg]
    dx, dy = x2 - x1, y2 - y1
    L = math.hypot(dx, dy)
    return (-dy / L * side, dx / L * side)


def seglen(seg):
    (x1, y1), (x2, y2) = SEG[seg]
    return math.hypot(x2 - x1, y2 - y1)


# --------------------------------------------------------------------------
# Sites: dense, evenly spread, stable ids. Identity is fixed per site; only
# on/off changes across timepoints, which is what keeps Morph well behaved.
# --------------------------------------------------------------------------
def build_sites():
    """Positions alternate spine, shaft, spine, shaft along every segment, so a
    shaft contact can never land on a spine. Adjacent spine and shaft sites are
    placed on opposite sides of the dendrite."""
    spines, shafts = [], []
    STEP = 16.0
    for seg in SEG:
        L = seglen(seg)
        n = max(6, int(L / STEP))
        for k in range(n):
            t = (k + 0.5) / n
            if t < 0.06 or t > 0.97:
                continue
            pair = k // 2
            if k % 2 == 0:
                side = 1 if pair % 2 == 0 else -1
                spines.append((f"sp_{seg}_{k:02d}", seg, t, side))
            else:
                side = -1 if pair % 2 == 0 else 1
                shafts.append((f"sh_{seg}_{k:02d}", seg, t, side))
    return spines, shafts


SPINES, SHAFTS = build_sites()

rng = random.Random(7)
_sp = [s[0] for s in SPINES]
rng.shuffle(_sp)
HVC_POOL = _sp[:22]                 # spine sites that belong to HVC
LMAN_SP_POOL = _sp[22:36]           # spine sites that belong to LMAN
_sh = [s[0] for s in SHAFTS]
rng.shuffle(_sh)
LMAN_SH_POOL = _sh[:11]
IN_POOL = _sh[11:25]

# counts per timepoint: (hvc_spine, lman_spine, lman_shaft, in_shaft)
COUNTS = {
    "p25": (2, 13, 10, 13),
    "p50": (22, 10, 7, 10),
    "p70": (15, 6, 5, 7),
    "p90": (12, 5, 4, 6),
}
META = {
    "p25": ("25 dph  ·  early subsong",
            "HVC\u2192RA immature. LMAN input is maximal, on shaft and spine. Interneuron contacts dense and non-specific."),
    "p50": ("50 dph  ·  subsong \u2192 plastic",
            "Total synapse number peaks. HVC connections are at their most numerous, before pruning."),
    "p70": ("70 dph  ·  late plastic song",
            "HVC pruned toward the adult pattern, LMAN reduced. Song is still variable."),
    "p90": ("> 90 dph  ·  crystallised song",
            "HVC fewer but stronger. LMAN stable and low. Inhibition positioned near LMAN input."),
}



# --------------------------------------------------------------------------
# Axonal arbors. Each input gets a backbone that parallels the dendritic tree
# at a fixed offset, plus a short terminal stalk from that backbone to every
# bouton it supplies. No bouton is left floating.
# --------------------------------------------------------------------------
CHAINS = [("trunk", "L1", "L2"), ("trunk", "R1", "R3"), ("L3",), ("R2",)]


def offset_chain(names, d):
    """Polyline running parallel to a chain of segments, offset by d."""
    pts = []
    for nm in names:
        (x1, y1), (x2, y2) = SEG[nm]
        ox, oy = nrm(nm, 1)
        pts.append((x1 + ox * d, y1 + oy * d))
        pts.append((x2 + ox * d, y2 + oy * d))
    return pts


def smooth_path(pts):
    """Catmull-Rom through the points, emitted as cubic beziers."""
    if len(pts) < 2:
        return ""
    d = [f"M {pts[0][0]:.1f} {pts[0][1]:.1f}"]
    for i in range(len(pts) - 1):
        p0 = pts[i - 1] if i > 0 else pts[i]
        p1, p2 = pts[i], pts[i + 1]
        p3 = pts[i + 2] if i + 2 < len(pts) else p2
        c1 = (p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6)
        c2 = (p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6)
        d.append(f"C {c1[0]:.1f} {c1[1]:.1f} {c2[0]:.1f} {c2[1]:.1f} {p2[0]:.1f} {p2[1]:.1f}")
    return " ".join(d)


def densify(pts, step=5.0):
    out = []
    for i in range(len(pts) - 1):
        (x1, y1), (x2, y2) = pts[i], pts[i + 1]
        L = math.hypot(x2 - x1, y2 - y1)
        n = max(1, int(L / step))
        for k in range(n):
            f = k / n
            out.append((x1 + (x2 - x1) * f, y1 + (y2 - y1) * f))
    out.append(pts[-1])
    return out


def nearest(samples, p):
    return min(samples, key=lambda q: (q[0] - p[0]) ** 2 + (q[1] - p[1]) ** 2)


def bouton_xy(seg, t, side, kind):
    """Where the bouton actually sits, matching draw_spine / draw_shaft."""
    px, py = pt(seg, t)
    nx, ny = nrm(seg, side)
    if kind == "spine":
        return (px + nx * 29, py + ny * 29)     # 17 neck + 12 offset
    return (px + nx * 13, py + ny * 13)


def arbor(C, colour, offset_d, entry, boutons, width=3.4, dash=""):
    """Backbone trimmed to the branches this input actually supplies, plus a
    short terminal stalk to every bouton. Nothing is drawn where nothing is
    innervated, so the arbor thins out as synapses are pruned."""
    chains = [densify(offset_chain(nm, offset_d)) for nm in CHAINS]

    # assign each bouton to its nearest point on any chain
    assign = {i: [] for i in range(len(chains))}
    stalks = []
    for bx, by in boutons:
        best = None
        for ci, samp in enumerate(chains):
            for si, (qx, qy) in enumerate(samp):
                d2 = (qx - bx) ** 2 + (qy - by) ** 2
                if best is None or d2 < best[0]:
                    best = (d2, ci, si)
        _, ci, si = best
        assign[ci].append(si)
        stalks.append((chains[ci][si], (bx, by)))

    g = []
    live = [ci for ci in assign if assign[ci]]
    if not live:
        return ""
    # lead-in from the source box to the start of the busiest chain
    root = chains[max(live, key=lambda c: len(assign[c]))][0]
    g.append(f'  <path d="M {entry[0]:.0f} {entry[1]:.0f} Q {(entry[0]+root[0])/2:.0f} '
             f'{(entry[1]+root[1])/2:.0f} {root[0]:.0f} {root[1]:.0f}" fill="none" '
             f'stroke="{colour}" stroke-width="{width+1.2}" stroke-linecap="round"{dash}/>\n')
    for ci in live:
        last = min(len(chains[ci]) - 1, max(assign[ci]) + 3)
        trimmed = chains[ci][:last + 1][::4] + [chains[ci][last]]
        g.append(f'  <path id="arb_{ci}" d="{smooth_path(trimmed)}" fill="none" '
                 f'stroke="{colour}" stroke-width="{width}" stroke-linecap="round" '
                 f'stroke-linejoin="round"{dash}/>\n')
    for a_pt, b_pt in stalks:
        mx, my = (a_pt[0] + b_pt[0]) / 2, (a_pt[1] + b_pt[1]) / 2
        g.append(f'  <path d="M {a_pt[0]:.1f} {a_pt[1]:.1f} Q {mx:.1f} {my:.1f} '
                 f'{b_pt[0]:.1f} {b_pt[1]:.1f}" fill="none" stroke="{colour}" '
                 f'stroke-width="2.1" stroke-linecap="round"{dash}/>\n')
    return "".join(g)


def txt(C, x, y, s, size=22, fill=None, anchor="start", weight="400", ident=None, style=""):
    fill = fill or C["text"]
    i = f' id="{ident}"' if ident else ""
    return (f'<text{i} x="{x}" y="{y}" font-family="{FAM}" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}" style="{style}">{s}</text>\n')


def dendrite(C):
    g = ['<g id="pn_cell">\n']
    for name, ((x1, y1), (x2, y2)) in SEG.items():
        g.append(f'  <line id="dend_{name}" x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" '
                 f'stroke="{C["dend"]}" stroke-width="{SEG_W[name]}" stroke-linecap="round"/>\n')
    sx, sy = SOMA
    g.append(f'  <line id="pn_axon" x1="{sx}" y1="{sy+42}" x2="{sx}" y2="822" '
             f'stroke="{C["dend"]}" stroke-width="9" stroke-linecap="round"/>\n')
    g.append(f'  <path id="pn_axon_arrow" d="M {sx-12} 816 L {sx} 842 L {sx+12} 816 Z" '
             f'fill="{C["dend"]}"/>\n')
    g.append(f'  <ellipse id="pn_soma" cx="{sx}" cy="{sy}" rx="60" ry="49" fill="{C["pn"]}" '
             f'stroke="{C["pn_stroke"]}" stroke-width="3"/>\n')
    g.append(txt(C, sx, sy + 8, "RA PN", 21, "#FFFFFF", "middle", "700", ident="lbl_pn"))
    g.append(txt(C, sx + 24, 806, "to nXIIts", 18, C["muted"], "start", ident="lbl_nxiits"))
    g.append('</g>\n')
    return "".join(g)


def draw_spine(C, sid, seg, t, side, occ, ghost=False):
    px, py = pt(seg, t)
    nx, ny = nrm(seg, side)
    hx, hy = px + nx * 17, py + ny * 17
    g = [f'<g id="{sid}">\n']
    g.append(f'  <line id="{sid}_neck" x1="{px}" y1="{py}" x2="{hx}" y2="{hy}" '
             f'stroke="{C["dend"]}" stroke-width="4" stroke-linecap="round"/>\n')
    g.append(f'  <circle id="{sid}_head" cx="{hx}" cy="{hy}" r="7.5" fill="{C["dend"]}"/>\n')
    if occ:
        bx, by = hx + nx * 12, hy + ny * 12
        if occ == "hvc":
            col = C["hvc_dim"] if ghost else C["hvc"]
            d = ' stroke-dasharray="3 3"' if ghost else ""
            g.append(f'  <circle id="{sid}_b_hvc" cx="{bx}" cy="{by}" r="8.5" fill="{col}" '
                     f'stroke="{C["hvc"]}" stroke-width="1.5"{d}/>\n')
        else:
            g.append(f'  <circle id="{sid}_b_lman" cx="{bx}" cy="{by}" r="11" fill="{C["lman"]}" '
                     f'stroke="{C["lman"]}" stroke-width="1.5"/>\n')
    g.append('</g>\n')
    return "".join(g)


def draw_shaft(C, sid, seg, t, side, occ):
    px, py = pt(seg, t)
    nx, ny = nrm(seg, side)
    bx, by = px + nx * 13, py + ny * 13
    g = [f'<g id="{sid}">\n']
    if occ == "lman":
        g.append(f'  <circle id="{sid}_b_lman" cx="{bx}" cy="{by}" r="11" fill="{C["lman"]}" '
                 f'stroke="{C["lman"]}" stroke-width="1.5"/>\n')
    elif occ == "in":
        ang = math.degrees(math.atan2(ny, nx))
        g.append(f'  <rect id="{sid}_b_in" x="{bx-7}" y="{by-13}" width="14" height="26" rx="4" '
                 f'transform="rotate({ang-90} {bx} {by})" fill="{C["bg"]}" stroke="{C["inh"]}" '
                 f'stroke-width="3" stroke-dasharray="5 4"/>\n')
    g.append('</g>\n')
    return "".join(g)


def counts_panel(C, key):
    """Relative synapse number per input class. The interneuron bar is the
    unknown the project measures, so it is drawn hollow with a question mark."""
    hs, ls, lsh, ins = COUNTS[key]
    maxes = (22, 24, 14)   # hvc, lman(total), in  -- scaled to the global maxima
    vals = [("HVC", hs, C["hvc"], False),
            ("LMAN", ls + lsh, C["lman"], False),
            ("Interneuron", ins, C["inh"], True)]
    x0, y0, bw = 1080, 300, 330
    g = ['<g id="counts_panel">\n']
    g.append(f'  <rect id="counts_bg" x="{x0-40}" y="{y0-72}" width="{bw+90}" height="290" rx="18" '
             f'fill="{C["panel"]}"/>\n')
    g.append(txt(C, x0 - 12, y0 - 34, "Synapses per projection neuron", 20, C["text"],
                 weight="700", ident="counts_title"))
    g.append(txt(C, x0 - 12, y0 - 10, "relative, schematic", 16, C["muted"],
                 ident="counts_sub", style="font-style:italic"))
    for k, ((label, v, col, unknown), mx) in enumerate(zip(vals, maxes)):
        y = y0 + 34 + k * 62
        g.append(txt(C, x0 - 12, y - 8, label, 18, col, weight="600", ident=f"cbar{k}_lbl"))
        g.append(f'  <rect id="cbar{k}_track" x="{x0-12}" y="{y}" width="{bw}" height="16" rx="8" '
                 f'fill="{C["bg"]}"/>\n')
        wpx = max(6, bw * v / mx)
        if unknown:
            g.append(f'  <rect id="cbar{k}_fill" x="{x0-12}" y="{y}" width="{wpx}" height="16" rx="8" '
                     f'fill="none" stroke="{col}" stroke-width="2.5" stroke-dasharray="5 4"/>\n')
            g.append(txt(C, x0 - 12 + wpx + 14, y + 14, "?", 22, col, weight="700",
                         ident=f"cbar{k}_q"))
        else:
            g.append(f'  <rect id="cbar{k}_fill" x="{x0-12}" y="{y}" width="{wpx}" height="16" rx="8" '
                     f'fill="{col}"/>\n')
    g.append('</g>\n')
    return "".join(g)


def legend(C):
    g = ['<g id="legend">\n']
    items = [("HVC \u00b7 AMPA \u00b7 spine", C["hvc"], "disc", False),
             ("LMAN \u00b7 NMDA \u00b7 shaft + spine", C["lman"], "disc", False),
             ("Interneuron \u00b7 shaft", C["inh"], "bar", True)]
    x0, y0 = 1040, 706
    for k, (label, col, shape, dashed) in enumerate(items):
        y = y0 + k * 32
        d = ' stroke-dasharray="5 4"' if dashed else ""
        f = "none" if dashed else col
        if shape == "disc":
            g.append(f'  <circle id="leg{k}_mark" cx="{x0}" cy="{y-6}" r="9" fill="{f}" '
                     f'stroke="{col}" stroke-width="2.5"{d}/>\n')
        else:
            g.append(f'  <rect id="leg{k}_mark" x="{x0-7}" y="{y-18}" width="14" height="25" rx="4" '
                     f'fill="{f}" stroke="{col}" stroke-width="2.5"{d}/>\n')
        g.append(txt(C, x0 + 24, y, label, 18, C["muted"], ident=f"leg{k}_label"))
    g.append(txt(C, x0 - 4, y0 + 3 * 32 + 4, "dashed = measured by this project", 17, C["inh"],
                 ident="leg_note", style="font-style:italic"))
    g.append('</g>\n')
    return "".join(g)


def inputs(C, hvc_ghost, hvc_bout, lman_bout):
    g = ['<g id="inputs">\n']
    hop, hd = (0.34, ' stroke-dasharray="9 7"') if hvc_ghost else (1.0, "")
    g.append(f'  <rect id="box_hvc" x="88" y="122" width="240" height="100" rx="14" '
             f'fill="{C["hvc"]}" fill-opacity="{0.14*hop:.3f}" stroke="{C["hvc"]}" '
             f'stroke-width="3" stroke-opacity="{hop}"{hd}/>\n')
    g.append(txt(C, 208, 164, "HVC", 32, C["hvc"], "middle", "700", ident="lbl_hvc",
                 style=f"opacity:{hop}"))
    g.append(txt(C, 208, 196, "AMPA \u00b7 fast", 18, C["hvc"], "middle", ident="lbl_hvc_sub",
                 style=f"opacity:{hop}"))
    g.append(f'<g id="axon_hvc" opacity="{hop}">\n')
    g.append(arbor(C, C["hvc"], 34, (328, 190), hvc_bout, 3.4, hd))
    g.append('</g>\n')

    g.append(f'  <rect id="box_lman" x="88" y="700" width="266" height="106" rx="14" '
             f'fill="{C["lman"]}" fill-opacity="0.14" stroke="{C["lman"]}" stroke-width="3"/>\n')
    g.append(txt(C, 221, 744, "LMAN", 32, C["lman"], "middle", "700", ident="lbl_lman"))
    g.append(txt(C, 221, 776, "NMDA \u00b7 slow", 18, C["lman"], "middle", ident="lbl_lman_sub"))
    g.append('<g id="axon_lman">\n')
    g.append(arbor(C, C["lman"], -34, (300, 700), lman_bout, 3.4))
    g.append('</g>\n')
    g.append('</g>\n')
    return "".join(g)


def interneuron(C, in_bout):
    cx, cy = 1000.0, 640.0
    d = ' stroke-dasharray="8 6"'
    g = ['<g id="interneuron">\n']
    g.append('<g id="in_axon">\n')
    g.append(arbor(C, C["inh"], -60, (cx - 34, cy - 24), in_bout, 3.0, d))
    g.append('</g>\n')
    g.append(f'  <path id="in_dend_a" d="M {cx} {cy-40} L {cx-30} {cy-104}" fill="none" '
             f'stroke="{C["inh"]}" stroke-width="4" stroke-linecap="round"/>\n')
    g.append(f'  <path id="in_dend_b" d="M {cx} {cy+40} L {cx+34} {cy+102}" fill="none" '
             f'stroke="{C["inh"]}" stroke-width="4" stroke-linecap="round"/>\n')
    g.append(f'  <circle id="in_soma" cx="{cx}" cy="{cy}" r="40" fill="{C["bg"]}" '
             f'stroke="{C["inh"]}" stroke-width="4"{d}/>\n')
    g.append(txt(C, cx, cy + 8, "IN", 22, C["inh"], "middle", "700", ident="lbl_in"))
    g.append('</g>\n')
    return "".join(g)


def build(key, theme):
    C = THEMES[theme]
    hs, ls, lsh, ins = COUNTS[key]
    title, cap = META[key]
    hvc_on = set(HVC_POOL[:hs])
    lman_sp_on = set(LMAN_SP_POOL[:ls])
    lman_sh_on = set(LMAN_SH_POOL[:lsh])
    in_on = set(IN_POOL[:ins])
    ghost = (key == "p25")

    s = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">\n',
         f'<g id="bg_slide"><rect id="bg_rect" x="0" y="0" width="{W}" height="{H}" '
         f'fill="{C["bg"]}"/></g>\n']
    s.append(txt(C, 88, 76, title, 38, C["text"], weight="700", ident="slide_title"))
    s.append(txt(C, 88, 110, cap, 20, C["muted"], ident="slide_caption"))
    hvc_b, lman_b, in_b = [], [], []
    for sid, seg, t, side in SPINES:
        if sid in hvc_on:
            hvc_b.append(bouton_xy(seg, t, side, "spine"))
        elif sid in lman_sp_on:
            lman_b.append(bouton_xy(seg, t, side, "spine"))
    for sid, seg, t, side in SHAFTS:
        if sid in lman_sh_on:
            lman_b.append(bouton_xy(seg, t, side, "shaft"))
        elif sid in in_on:
            in_b.append(bouton_xy(seg, t, side, "shaft"))
    s.append(inputs(C, ghost, hvc_b, lman_b))
    s.append(interneuron(C, in_b))
    s.append('<g id="cell_and_synapses">\n')
    s.append(dendrite(C))
    s.append('<g id="synapses">\n')
    for sid, seg, t, side in SPINES:
        occ = "hvc" if sid in hvc_on else ("lman" if sid in lman_sp_on else None)
        s.append(draw_spine(C, sid, seg, t, side, occ, ghost and occ == "hvc"))
    for sid, seg, t, side in SHAFTS:
        occ = "lman" if sid in lman_sh_on else ("in" if sid in in_on else None)
        s.append(draw_shaft(C, sid, seg, t, side, occ))
    s.append('</g>\n</g>\n')
    s.append(counts_panel(C, key))
    s.append(legend(C))
    s.append(txt(C, 88, 886,
                 "Arbor identical at every timepoint. What changes is the number of synapses, not the size of the cell.",
                 18, C["muted"], ident="footer", style="font-style:italic"))
    s.append('</svg>\n')
    return "".join(s)


for theme in ("light", "dark"):
    out = f"/home/claude/svg2/{theme}"
    os.makedirs(out, exist_ok=True)
    for i, key in enumerate(["p25", "p50", "p70", "p90"], start=3):
        fn = f"{i:02d}_ra_{key}.svg"
        open(os.path.join(out, fn), "w").write(build(key, theme))
    print(theme, "done", {k: sum(v) for k, v in COUNTS.items()})
