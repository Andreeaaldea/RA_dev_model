#!/usr/bin/env python3
"""
Song system diagram (two build stages) + dendrite zoom.
Same 1600 x 900 canvas, palette and id conventions as gen_ra_svgs.py.
"""
import os

W, H = 1600, 900
C = dict(
    hvc="#0E7C8B", lman="#C9421C", inh="#6B2FB5",
    pn="#2E3550", pn_stroke="#2E3550",
    bg="#F7F8FA", text="#1A1D26", muted="#5C6472",
    dend="#98A1B3", neutral="#7A8496",
)
OUT = "/home/claude/svg"
os.makedirs(OUT, exist_ok=True)
FAM = "Calibri, Carlito, Candara, sans-serif"


def txt(x, y, s, size=22, fill=None, anchor="start", weight="400", ident=None, style=""):
    fill = fill or C["text"]
    i = f' id="{ident}"' if ident else ""
    return (f'<text{i} x="{x}" y="{y}" font-family="{FAM}" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}" style="{style}">{s}</text>\n')


def defs():
    d = ['<defs>\n']
    for name, col in [("hvc", C["hvc"]), ("lman", C["lman"]), ("neutral", C["neutral"]),
                      ("inh", C["inh"]), ("dend", C["dend"])]:
        d.append(f'  <marker id="arrow_{name}" viewBox="0 0 12 12" refX="10" refY="6" '
                 f'markerWidth="6" markerHeight="6" orient="auto-start-reverse">\n'
                 f'    <path d="M 0 0 L 12 6 L 0 12 z" fill="{col}"/>\n  </marker>\n')
    d.append('</defs>\n')
    return "".join(d)


def bg():
    return (f'<g id="bg_slide"><rect id="bg_rect" x="0" y="0" width="{W}" height="{H}" '
            f'fill="{C["bg"]}"/></g>\n')


def node(ident, x, y, w, h, label, sub, col, filled=False, label_size=34):
    """Rounded box for a nucleus."""
    op = 0.9 if filled else 0.16
    tcol = "#FFFFFF" if filled else col
    g = [f'<g id="{ident}">\n']
    g.append(f'  <rect id="{ident}_box" x="{x}" y="{y}" width="{w}" height="{h}" rx="16" '
             f'fill="{col}" fill-opacity="{op}" stroke="{col}" stroke-width="3.5"/>\n')
    cy = y + h / 2
    if sub:
        g.append(txt(x + w / 2, cy - 2, label, label_size, tcol, "middle", "700", ident=f"{ident}_lbl"))
        g.append(txt(x + w / 2, cy + 28, sub, 18, tcol, "middle", ident=f"{ident}_sub",
                     style="opacity:0.85"))
    else:
        g.append(txt(x + w / 2, cy + 11, label, label_size, tcol, "middle", "700", ident=f"{ident}_lbl"))
    g.append('</g>\n')
    return "".join(g)


def arrow(ident, x1, y1, x2, y2, col, marker, width=5, dash=""):
    d = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'  <line id="{ident}" x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{col}" '
            f'stroke-width="{width}" marker-end="url(#arrow_{marker})" stroke-linecap="round"{d}/>\n')


# ----------------------------------------------------------------------------
# 01 / 02  Song system, built additively
# ----------------------------------------------------------------------------
def song_system(stage):
    """stage 1 = motor pathway only. stage 2 = motor pathway + AFP loop."""
    s = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">\n',
         defs(), bg()]
    title = ("The motor pathway" if stage == 1
             else "Two pathways converge on RA")
    cap = ("HVC drives RA, which drives the brainstem motor neurons for the syrinx and respiration."
           if stage == 1 else
           "HVC supplies precise timing. The anterior forebrain pathway, via LMAN, supplies variability.")
    s.append(txt(96, 84, title, 40, C["text"], weight="700", ident="slide_title"))
    s.append(txt(96, 120, cap, 21, C["muted"], ident="slide_caption"))

    # --- AFP loop first so it sits behind ---
    if stage == 2:
        s.append('<g id="afp_group">\n')
        s.append(f'  <rect id="afp_frame" x="770" y="128" width="740" height="622" rx="22" '
                 f'fill="none" stroke="{C["muted"]}" stroke-width="2.5" stroke-dasharray="9 8"/>\n')
        s.append(txt(1490, 728, "anterior forebrain pathway", 18, C["muted"], "end",
                     ident="afp_frame_lbl", style="font-style:italic"))
        s.append(node("n_lman", 1200, 190, 270, 116, "LMAN", "cortical", C["lman"]))
        s.append(node("n_areax", 1200, 578, 270, 116, "Area X", "basal ganglia", C["neutral"]))
        s.append(node("n_dlm", 830, 578, 250, 116, "DLM", "thalamus", C["neutral"]))
        # HVC -> Area X, routed outside the AFP frame so nothing crosses
        s.append(f'  <path id="a_hvc_areax" d="M 540 215 V 160 H 1545 V 636 H 1482" fill="none" '
                 f'stroke="{C["neutral"]}" stroke-width="4" stroke-linejoin="round" '
                 f'marker-end="url(#arrow_neutral)"/>\n')
        s.append(arrow("a_areax_dlm", 1196, 636, 1086, 636, C["neutral"], "neutral", 4))
        s.append(arrow("a_dlm_lman", 955, 574, 1288, 312, C["neutral"], "neutral", 4))
        s.append(arrow("a_lman_areax", 1440, 310, 1440, 574, C["neutral"], "neutral", 4))
        # LMAN -> RA : the variability input
        s.append(arrow("a_lman_ra", 1196, 290, 550, 462, C["lman"], "lman", 6))
        s.append(txt(880, 344, "variability", 24, C["lman"], "middle", "700", ident="lbl_variability"))
        s.append('</g>\n')

    # --- motor pathway, always present ---
    s.append('<g id="motor_group">\n')
    s.append(node("n_hvc", 290, 190, 250, 110, "HVC", "", C["hvc"]))
    s.append(node("n_ra", 290, 430, 250, 110, "RA", "", C["pn"], filled=True))
    s.append(f'  <rect id="n_ra_ring" x="286" y="426" width="258" height="118" rx="18" '
             f'fill="none" stroke="{C["pn_stroke"]}" stroke-width="3"/>\n')
    s.append(node("n_nxiits", 268, 690, 294, 116, "nXIIts", "syringeal muscles", C["neutral"],
                  label_size=30))
    s.append(arrow("a_hvc_ra", 415, 304, 415, 424, C["hvc"], "hvc", 6))
    s.append(txt(438, 372, "motor", 24, C["hvc"], "start", "700", ident="lbl_motor"))
    s.append(arrow("a_ra_nxiits", 415, 544, 415, 684, C["dend"], "dend", 6))
    s.append(txt(438, 622, "premotor output", 19, C["muted"], "start", ident="lbl_premotor"))
    s.append('</g>\n')

    s.append(txt(96, 838,
                 "RA is where the two pathways meet. This project asks how that convergence is wired.",
                 20, C["muted"], ident="footer", style="font-style:italic"))
    s.append('</svg>\n')
    return "".join(s)


# ----------------------------------------------------------------------------
# 07  Dendrite zoom: why the position of inhibition matters
# ----------------------------------------------------------------------------
def dendrite_zoom():
    """Prediction 2 of the hypothesis: inhibitory synapses lie close in cable
    distance to LMAN inputs, so the shunt is selective for LMAN."""
    s = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">\n',
         defs(), bg()]
    s.append(txt(96, 84, "Where inhibition sits decides what it gates", 40, C["text"],
                 weight="700", ident="slide_title"))
    s.append(txt(96, 120,
                 "Inhibition placed close in cable distance to LMAN inputs shunts LMAN selectively.",
                 21, C["muted"], ident="slide_caption"))

    SY = 500.0
    # shunt zone, drawn first so it sits behind
    s.append(f'<g id="gate_zone">\n'
             f'  <rect id="gate_rect" x="640" y="376" width="250" height="258" rx="20" '
             f'fill="{C["inh"]}" fill-opacity="0.10" stroke="{C["inh"]}" stroke-width="2.5" '
             f'stroke-dasharray="7 6"/>\n</g>\n')

    s.append('<g id="dendrite">\n')
    s.append(f'  <line id="shaft" x1="250" y1="{SY}" x2="1400" y2="{SY}" stroke="{C["dend"]}" '
             f'stroke-width="34" stroke-linecap="round"/>\n')
    s.append(arrow("a_to_soma", 330, 620, 196, 620, C["muted"], "neutral", 4))
    s.append(txt(348, 627, "to soma", 20, C["muted"], ident="lbl_to_soma"))
    s.append('</g>\n')

    spines = [("dz_sp1", 400, "hvc"), ("dz_sp2", 830, "lman"),
              ("dz_sp3", 1140, "hvc"), ("dz_sp4", 1320, "hvc")]
    s.append('<g id="dz_spines">\n')
    for sid, sx, occ in spines:
        hy = SY - 74
        col = C["hvc"] if occ == "hvc" else C["lman"]
        r = 26 if occ == "hvc" else 32
        s.append(f'  <g id="{sid}">\n')
        s.append(f'    <line id="{sid}_neck" x1="{sx}" y1="{SY-14}" x2="{sx}" y2="{hy}" '
                 f'stroke="{C["dend"]}" stroke-width="11" stroke-linecap="round"/>\n')
        s.append(f'    <circle id="{sid}_head" cx="{sx}" cy="{hy}" r="23" fill="{C["dend"]}"/>\n')
        s.append(f'    <circle id="{sid}_bouton" cx="{sx}" cy="{hy-50}" r="{r}" fill="{col}" '
                 f'stroke="{col}" stroke-width="2"/>\n')
        s.append('  </g>\n')
    s.append('</g>\n')

    s.append(f'<g id="dz_lman_shaft">\n'
             f'  <circle id="dz_lman_shaft_bouton" cx="690" cy="{SY+56}" r="34" fill="{C["lman"]}" '
             f'stroke="{C["lman"]}" stroke-width="2"/>\n</g>\n')

    s.append(f'<g id="dz_inhib">\n'
             f'  <rect id="dz_in_bar" x="745" y="{SY-42}" width="30" height="84" rx="8" '
             f'fill="{C["bg"]}" stroke="{C["inh"]}" stroke-width="4.5" stroke-dasharray="7 5"/>\n'
             f'</g>\n')

    # labels
    s.append(txt(765, 248, "LMAN  \u00b7  NMDA  \u00b7  slow", 26, C["lman"], "middle", "700",
                 ident="lbl_lman_dz"))
    s.append(txt(765, 278, "shaft and spine", 19, C["lman"], "middle", ident="lbl_lman_dz_sub",
                 style="opacity:0.85"))
    s.append(f'  <line id="lead_lman" x1="830" y1="292" x2="830" y2="340" stroke="{C["lman"]}" '
             f'stroke-width="2"/>\n')

    s.append(txt(1230, 248, "HVC  \u00b7  AMPA  \u00b7  fast", 26, C["hvc"], "middle", "700",
                 ident="lbl_hvc_dz"))
    s.append(txt(1230, 278, "spine heads", 19, C["hvc"], "middle", ident="lbl_hvc_dz_sub",
                 style="opacity:0.85"))
    s.append(f'  <line id="lead_hvc" x1="1200" y1="292" x2="1150" y2="340" stroke="{C["hvc"]}" '
             f'stroke-width="2"/>\n')

    s.append(f'  <line id="lead_in" x1="748" y1="{SY+46}" x2="620" y2="666" stroke="{C["inh"]}" '
             f'stroke-width="2"/>\n')
    s.append(txt(560, 692, "Inhibitory contact on the shaft", 24, C["inh"], "middle", "700",
                 ident="lbl_in_dz"))
    s.append(txt(560, 720, "position and number: measured by this project", 19, C["inh"], "middle",
                 ident="lbl_in_dz_sub", style="font-style:italic; opacity:0.85"))

    s.append(txt(765, 606, "shunt zone", 21, C["inh"], "middle", "700", ident="lbl_shunt"))

    s.append(txt(96, 812,
                 "HVC contacts spine heads. LMAN contacts both shaft and spine.",
                 21, C["muted"], ident="foot1"))
    s.append(txt(96, 846,
                 "Prediction 2: inhibition sits close in cable distance to LMAN, so the shunt spares HVC.",
                 21, C["text"], ident="foot2"))
    s.append('</svg>\n')
    return "".join(s)


for fn, content in [("01_song_system_motor.svg", song_system(1)),
                    ("02_song_system_full.svg", song_system(2)),
                    ("07_dendrite_zoom.svg", dendrite_zoom())]:
    open(os.path.join(OUT, fn), "w").write(content)
    print("wrote", fn)
