#!/usr/bin/env python3
"""
export_traces.py  --  produce traces.json for the viva visualisation.

Drop this in the ra-connectome repo (suggested: viz/export_traces.py) and wire
the three TODO blocks to the existing simulation code. Everything else here is
already complete: the metric definitions follow Methods 4.5 of the first-year
report exactly, so the numbers this writes out are the same ones quoted in
Figure 5.

    python viz/export_traces.py --out viz/traces.json

Metric definitions (Methods 4.5):
  spike           membrane potential crosses -10 mV
  analysis window 25 ms from each HVC command onset
  reliability     fraction of commands evoking at least one spike
  onset jitter    across-trial SD of first-spike latency within each command
                  window, averaged over the 8 commands
  inter-burst     spikes falling outside every command window, per trial
  command-driven  reliability >= 0.9 AND inter-burst spikes <= 4 per trial
"""

from __future__ import annotations
import argparse, json, statistics, datetime
from dataclasses import dataclass, asdict

# --------------------------------------------------------------------------
# Protocol constants. These match the report; change here if the rig changes.
# --------------------------------------------------------------------------
MOTIF_MS      = 500.0
N_TRIALS      = 8
COMMAND_TIMES = [50.0 + 60.0 * i for i in range(8)]   # 50 .. 470 ms
WINDOW_MS     = 25.0
SPIKE_THRESH  = -10.0        # mV
HOLD_NA       = -0.3
N_LMAN_AXONS  = 2
HVC_TOTAL_NS  = 11.0
Q10_NMDA      = 2.5
TEMP_C        = 40.0

# The three cases shown in the talk, physiological first.
CASES = [
    {"id": "5.0", "g_total_nS": 5.0,  "rate_hz": 21,
     "label": "one measured fibre", "note": "physiological, directed singing"},
    {"id": "9.5", "g_total_nS": 9.5,  "rate_hz": 21,
     "label": "full recruitment",   "note": "maximal measured drive"},
    {"id": "3.0", "g_total_nS": 3.0,  "rate_hz": 21,
     "label": "model operating point", "note": "sub-physiological"},
]

# Full sweep for the grid on the right of the figure (Figure 5B).
SWEEP_G     = [1.0, 3.0, 5.0, 7.0, 10.0]
SWEEP_RATES = [5, 10, 21, 35]


# --------------------------------------------------------------------------
# TODO 1 -- run one trial of the model.
# --------------------------------------------------------------------------
def run_trial(g_total_nS: float, rate_hz: float, seed: int) -> dict:
    """Run a single 500 ms trial and return the recorded arrays.

    Must return:
        {
          "t_ms":       list[float],   # recording time base
          "vm_mV":      list[float],   # somatic membrane potential
          "hvc_spikes": list[float],   # HVC presynaptic spike times, ms
          "lman_spikes": list[list[float]],  # one list per LMAN axon
        }

    Wire this to the existing NEURON code. The LMAN Poisson trains must differ
    between trials (use `seed`) while the HVC burst motif stays identical, so
    that all output variability comes from LMAN.
    """
    raise NotImplementedError(
        "Wire run_trial() to the NEURON simulation in this repo. "
        "See viz/README_viz.md for the Claude Code prompt."
    )


# --------------------------------------------------------------------------
# TODO 2 -- optional: reuse the existing Figure 5B sweep instead of re-running.
# --------------------------------------------------------------------------
def load_existing_sweep():
    """Return the Figure 5B sweep if it is already cached in the repo.

    Expected shape:
        {"jitter": {g: [j_at_rate5, j_at_rate10, j_at_rate21, j_at_rate35], ...},
         "command_driven": {g: [bool, bool, bool, bool], ...}}

    Return None to recompute the sweep by running the model.
    """
    return None


# --------------------------------------------------------------------------
# Metrics -- complete, no changes needed
# --------------------------------------------------------------------------
def detect_spikes(t_ms, vm_mV, thresh=SPIKE_THRESH):
    """Upward threshold crossings."""
    out = []
    for i in range(1, len(vm_mV)):
        if vm_mV[i - 1] < thresh <= vm_mV[i]:
            # linear interpolation onto the crossing
            f = (thresh - vm_mV[i - 1]) / (vm_mV[i] - vm_mV[i - 1])
            out.append(t_ms[i - 1] + f * (t_ms[i] - t_ms[i - 1]))
    return out


def first_latencies(spikes, command_t, window=WINDOW_MS):
    """First-spike latency within the window, or None if the command failed."""
    hits = [s - command_t for s in spikes if 0.0 <= s - command_t < window]
    return min(hits) if hits else None


def metrics(trials_spikes):
    """trials_spikes: list of per-trial PN spike time lists."""
    n_trials = len(trials_spikes)

    # reliability, over every command in every trial
    hit, tot = 0, 0
    for spikes in trials_spikes:
        for c in COMMAND_TIMES:
            tot += 1
            if first_latencies(spikes, c) is not None:
                hit += 1
    reliability = hit / tot if tot else 0.0

    # onset jitter: SD across trials per command, then mean across commands
    per_command_sd = []
    for c in COMMAND_TIMES:
        lats = [first_latencies(s, c) for s in trials_spikes]
        lats = [l for l in lats if l is not None]
        if len(lats) > 1:
            per_command_sd.append(statistics.stdev(lats))
    jitter = statistics.mean(per_command_sd) if per_command_sd else float("nan")

    # inter-burst spikes per trial
    def outside(s):
        return all(not (0.0 <= s - c < WINDOW_MS) for c in COMMAND_TIMES)
    ib = [sum(1 for s in spikes if outside(s)) for spikes in trials_spikes]
    interburst = statistics.mean(ib) if ib else 0.0

    # spikes per burst
    spb = []
    for spikes in trials_spikes:
        for c in COMMAND_TIMES:
            spb.append(sum(1 for s in spikes if 0.0 <= s - c < WINDOW_MS))
    spikes_per_burst = statistics.mean(spb) if spb else 0.0

    return {
        "reliability": round(reliability, 3),
        "jitter_ms": round(jitter, 3),
        "interburst_per_trial": round(interburst, 2),
        "spikes_per_burst": round(spikes_per_burst, 2),
        "command_driven": bool(reliability >= 0.9 and interburst <= 4),
    }


def decimate(t_ms, vm_mV, target_points=2500):
    """Thin the trace for the browser without losing spike peaks."""
    n = len(t_ms)
    if n <= target_points:
        return list(t_ms), list(vm_mV)
    step = n // target_points
    ts, vs = [], []
    for i in range(0, n, step):
        chunk = vm_mV[i:i + step]
        j = i + chunk.index(max(chunk))       # keep the peak in each bin
        ts.append(t_ms[j]); vs.append(vm_mV[j])
    return ts, vs


# --------------------------------------------------------------------------
def build_case(case):
    trials, display = [], None
    for k in range(N_TRIALS):
        rec = run_trial(case["g_total_nS"], case["rate_hz"], seed=1000 + k)
        spikes = detect_spikes(rec["t_ms"], rec["vm_mV"])
        trials.append(spikes)
        if k == 0:
            t, v = decimate(rec["t_ms"], rec["vm_mV"])
            display = {
                "t_ms": [round(x, 3) for x in t],
                "vm_mV": [round(x, 2) for x in v],
                "hvc_spikes": [round(x, 3) for x in rec["hvc_spikes"]],
                "lman_spikes": [[round(x, 3) for x in ax] for ax in rec["lman_spikes"]],
                "pn_spikes": [round(x, 3) for x in spikes],
            }
    out = dict(case)
    out.update(metrics(trials))
    out["display_trial"] = display
    out["all_trial_pn_spikes"] = [[round(x, 3) for x in s] for s in trials]
    return out


def build_grid():
    cached = load_existing_sweep()
    if cached:
        return {"rates": SWEEP_RATES, "g": SWEEP_G, **cached}
    jitter, cdrv = {}, {}
    for g in SWEEP_G:
        jrow, crow = [], []
        for r in SWEEP_RATES:
            trials = []
            for k in range(N_TRIALS):
                rec = run_trial(g, r, seed=2000 + k)
                trials.append(detect_spikes(rec["t_ms"], rec["vm_mV"]))
            m = metrics(trials)
            jrow.append(m["jitter_ms"]); crow.append(m["command_driven"])
        jitter[str(g)] = jrow; cdrv[str(g)] = crow
    return {"rates": SWEEP_RATES, "g": SWEEP_G, "jitter": jitter, "command_driven": cdrv}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="viz/traces.json")
    ap.add_argument("--skip-grid", action="store_true",
                    help="cases only; leaves the grid to be filled from the cached sweep")
    a = ap.parse_args()

    doc = {
        "meta": {
            "generated": datetime.datetime.now().isoformat(timespec="seconds"),
            "motif_ms": MOTIF_MS, "n_trials": N_TRIALS,
            "command_times_ms": COMMAND_TIMES, "window_ms": WINDOW_MS,
            "spike_threshold_mV": SPIKE_THRESH, "hold_nA": HOLD_NA,
            "n_lman_axons": N_LMAN_AXONS, "hvc_total_nS": HVC_TOTAL_NS,
            "q10_nmda": Q10_NMDA, "temp_C": TEMP_C,
        },
        "cases": [build_case(c) for c in CASES],
        "grid": None if a.skip_grid else build_grid(),
    }
    with open(a.out, "w") as f:
        json.dump(doc, f, indent=1)
    print(f"wrote {a.out}")
    for c in doc["cases"]:
        print(f"  {c['id']:>4} nS  jitter {c['jitter_ms']:.3f} ms  "
              f"reliability {c['reliability']:.2f}  "
              f"inter-burst {c['interburst_per_trial']:.1f}  "
              f"{'COMMAND-DRIVEN' if c['command_driven'] else 'decoupled'}")


if __name__ == "__main__":
    main()
