# Viva SVG assets

Light theme, Calibri, 1600 x 900, shared ids for Morph.

## Decluttering pass

**Roughly half the synapses.** Site pitch went from 16 px to 30 px and the
counts came down with it. Totals are now 18 / 23 / 15 / 12 across 25, 50, 70
and 90 dph. The ordering the literature supports is unchanged: HVC rises to a
peak at 50 dph then prunes, LMAN declines monotonically, and the total still
peaks at 50 dph.

**The weird axon turns were an offset bug.** Each dendritic segment was being
offset independently, which leaves a discontinuity at every branch point, and
smoothing a curve through that discontinuity produced the loops. Junctions are
now mitred to a single point before smoothing.

**Arbors run on both sides of the dendrite.** Previously each input had one
backbone on one side, so any contact on the far side was reached by a stalk
that cut straight across the shaft. Each input now has branches at both +offset
and -offset, and every bouton is served from its own side.

**Branches are trimmed at both ends.** A branch is drawn only over the stretch
it actually innervates, instead of always running back to the trunk. That
removed the long lines converging on the soma and means a sparsely innervated
branch simply is not there.

## Layout
Counts panel 1110-1450 x 196-486. Legend 1070-1450 x 600-760. Interneuron soma
at 916, 566 with a 40 px radius; its dendrites stop short of the legend.
Dendritic field ends near x 710. Nothing overlaps.

## Previews
PNGs were rasterised without Calibri installed, so they show a substitute face.
The SVGs specify Calibri and render correctly in Illustrator and PowerPoint.

## Knobs
`COUNTS` sets synapses per timepoint. `STEP` in `build_sites` sets site pitch.
`THEMES` sets the palette. `FAM` sets the font. Offsets are the third argument
to `arbor()` in `inputs()` and `interneuron()`.


## 08 expansion pipeline (scene 10)

Grey = published LICONN / iDISCO step. Teal with a numbered badge = a
modification introduced in this work. The three cards underneath state the
problem each one solved, so the slide answers "why did you change it" before
the question is asked.

Immunolabelling is shown after the re-slice, which is now the settled position.
If an examiner points at Figure 6F, where it appears before the second
expandable gel, the answer is that the order is after re-slicing and validation
is ongoing on the new chemistry.


## 09 roadmap + dividers (scene 2, and section breaks)

`09_roadmap.svg` is the contents slide. `09a` to `09d` are the four section
dividers: identical geometry, with one card active and the other three receded
to 32% opacity. Because every id matches, morphing roadmap to divider makes the
active card lift out while the rest fall back, and divider to divider walks the
highlight along. That gives you a running progress indicator for free without
adding a separate element to the deck.

The four sections are framed as questions rather than topics, so the roadmap
states what the talk will settle rather than what it will cover.

Status chips are deliberate: background, done this year, in progress, next 18
months. A first-year panel is assessing what you have actually done, so saying
it on the contents slide is better than leaving them to infer it.

Ordering note: section 2 is the model, placed before the methods. That is the
reordering discussed earlier, and it is what makes the methods read as "how I
get the data to test this" instead of a protocol tour.


## 02 roadmap (scene 2, and every section divider)

Five files, one design. `02a_roadmap_contents.svg` is the contents slide with
all four sections live. `02b` to `02e` are the same slide with one section
active and the other three dimmed to 42%, and the header replaced by that
section's name and one-line purpose.

Ids are shared across all five, so Morph carries the highlight along the rail
rather than cutting. Used as dividers, the audience always sees where they are
and how much is left, which is what stops a 25 minute talk feeling open-ended.

Timings on the cards are 8 + 5 + 7 + 5 = 25 min, leaving room inside 20-30.
They are also a rehearsal tool: if section 1 is running past 8 minutes in
practice, the intro is too long, which is the failure mode this talk is most
prone to.

Edit `SECTIONS` at the top of `gen_scene_svgs.py` to change titles, bullets,
timings or the divider subtitles. All five files regenerate together.


## 09 protocol comparison, 10 gel chemistry backup

09 is the talk slide, 10 is backup. The split matters: the full recipes will
lose a room, but you need them to hand because the chemistry is the part a
methods-minded examiner will dig into.

**On slide 09**, the highlight band marks every row that changed, which is all
of them except clearing. The three chips give the reasoning rather than the
recipe, because "why did you change it" is the question that gets asked and
"what is in it" is the one that gets asked second.

**What to be careful about when presenting this.** The comparison invites an
obvious question: if the new chemistry is better, what is the status of the
~13x data in the report? Have an answer ready. The honest one is that the
report data validated the architecture (a 1 mm block surviving two rounds), and
the new chemistry improves the labelling and the factor within that same
architecture, so the earlier work is not invalidated by it.

Two other things worth pre-empting:
- ~20x is described as the latest cohort, so be clear whether that is one gel
  or a reproducible number, and how it was measured. The report quantified ~13x
  from nucleolar diameter with a wide range (~11 to 17x), so the same caveat
  applies here.
- The homogenisation is described as "a first approach" to suppressing folding.
  Say that plainly rather than presenting 92 degrees for over 12 hours as
  settled. It reads as better science, and it is the truth.

**Attribution.** The slide names Sven in the subtitle. Keep it there.

## 11 labelling comparison, 12 expansion factor

Both are templates. The dashed boxes are image slots: drop your images in and
delete the placeholder rect and its two text lines. Slot ids are `cA_img_rect`,
`cB_img_rect` and `gel_img_rect`.

### 11
The left column is the report chemistry, the right is the new one, and the
banner at the bottom names the thing that makes it worth showing: same tissue,
same label, same imaging, only the gel differs. Say that out loud. A pair of
images without that sentence is just two pictures.

Practical asks when you place the images: matched scale bars, matched display
range, and state whether the acquisition settings were identical. If they were
not, say so on the slide, because "the new one looks brighter" is the first
thing anyone will think and the least interesting explanation.

### 12
This is a genuinely stronger measurement than the one in your report and the
slide says why. The report number came from nucleolar diameter in gel against a
published biological value, giving ~13x with a range of roughly 11 to 17x. A
1 mm vibratome section measured end to end at ~2 cm is a direct measurement of
a known starting dimension, which is a different and better class of evidence.

The caveats block is not padding, it is what stops the number being picked
apart:
- gel expansion is not automatically tissue expansion, so cross-check against
  an internal biological reference in the same sample. If the nucleolar
  estimate on the new gels also lands near 20x, two independent methods agree
  and the number becomes very hard to argue with. That would be worth doing
  before the viva if there is time.
- 1 mm is the vibratome nominal setting, not a measured thickness.
- be explicit about whether ~20x is one gel or reproduced across the cohort.
  "Latest cohort" implies more than one, so if it is reproduced, say the n.

## 13 segmentation

Template, two image slots (`sA_img_rect`, `sB_img_rect`).

**The argument you may be underselling.** The checkpoint was trained on LICONN
gels. That means the model is on home ground with your old sample and out of
domain with your new one. If it still segments the new gels better, the domain
shift is working against you and the result holds anyway. Say this explicitly.
It converts "the new gels look nicer" into an argument that is hard to dismiss,
and it costs one sentence.

**The confound to close off before someone else raises it.** The new gels are
~20x and the old ones ~13x, so the two samples differ in effective resolution
as well as in chemistry. Better segmentation could simply follow from finer
effective voxels. The fix is cheap: downsample the 20x data to match effective
voxel size and re-run. If the advantage survives, it is the labelling. If it
does not, you have learned something real and can still claim the pipeline
improvement, just for a different reason. Either way, do this before the viva
rather than being asked about it.

**State the metric.** Both slots have a red `metric: [state it here]` line to
fill. "Performs better" will not survive a question. If you have proofread
ground truth, expected run length or split and merge counts per unit length are
the standard connectomics choices. If you do not yet have ground truth, say the
comparison is qualitative and that quantifying it is exactly what the training
data you are generating is for. That is a perfectly good answer, and much
better than an unsupported claim.

**Ordering.** This slide belongs after 11 and 12. By the time it appears you
have shown better labelling and a higher expansion factor, and this is the
independent, quantitative confirmation that those gains matter downstream.

## 14 sampling design

The slide that answers "why six animals" and "how much will you reconstruct".

### The power numbers
For a two-sample comparison at 80% power and alpha 0.05, n per group is about
15.7 / d-squared. So n = 6 detects d ~ 1.6. A monotone trend contrast across
all four timepoints (weights -3, -1, +1, +3) detects a total change of about
1.5 SD. Both are large effects. Say so. Claiming sensitivity to subtle effects
would be false and easy to catch.

The four-timepoint design is not much more *powerful* than a single pairwise
comparison. Its value is that a monotone trend is more convincing evidence than
one difference, and that it can be tied to the behavioural timeline. Make that
argument rather than a power argument.

### Why the curve justifies about 10 cells
Nested data: synapses within cells within animals. The SE of a group mean goes
as sqrt(between-variance + within-variance / k) / sqrt(n). If the two variance
components are comparable, then relative to reconstructing infinitely many
cells, k = 1 costs 41% in SE, k = 5 costs 9.5%, k = 10 costs 4.9%, k = 20 costs
2.5%. Going from 10 to 20 cells buys about 2%, which is far less than one extra
animal for double the proofreading. That is the whole argument and it fits in a
sentence.

The curve assumes within- and between-animal variance are comparable. If within
turns out much larger, the optimum shifts up. The endpoints-first design gives
you the numbers to check this, which is another reason to name it as a pilot.

### Two things to check before you present
- What fraction of RA neurons are interneurons. If they are a small minority,
  finding 10 per animal drives your imaging volume rather than your
  proofreading time, and the constraint moves.
- Your actual proofreading hours per cell. That product, hours x cells, is the
  real feasibility number, and the footer says so. Imaging days are already in
  the report; reconstruction effort is not, and it is the question a
  connectomics-minded examiner will go to.

### The framing that does the work
Full RA reconstruction is not needed, and for predictions 1 and 2 complete
neurons are not needed either. Both are satisfied by sampled dendritic segments
of defined length, which decouples effort from arbor size and makes per-cell
cost predictable. Complete cells are reserved for total counts, IN to PN
wiring, and morphology for the model. Leading with that reframes the capacity
problem as a design choice rather than a limitation.

## model_viz.html — the interactive model figure

Open in a browser. Sized to 1600 x 900 to match the slides. Three buttons pick
the case; the animation loops the 500 ms motif at about 14x slower than real
time so the bursts are visible.

Left: HVC soma and two LMAN somas flashing as they spike, pulses travelling
down the axons to the PN soma, and four voltage traces underneath (HVC, both
LMAN axons pooled, the PN, and the HVC-locked target for comparison). Shaded
bands on the PN traces mark the HVC command windows, so inter-burst spikes are
visible as deflections outside the bands.

Right: the Figure 5B grid. Only the active cell shows its value, so the grid
fills in as you step through cases rather than presenting all twenty at once.

### Read this before you use it
**The traces are synthesised, not NEURON output.** I cannot run NEURON here, so
spike trains are generated with the right statistics (HVC 8 bursts of 4 at
650 Hz, LMAN Poisson at 21 Hz per axon, PN bursts with the stated jitter and
inter-burst counts). There is a `REAL` hook at the top of the script. Export
spike times from your model and set:

    REAL = { "3": {hvc:[...], lman:[[...],[...]], pn:[...]},
             "5": {...}, "9.5": {...} }

Times in ms. Do this before the viva. Presenting synthetic traces as model
output would be misrepresenting your results, and the fix is an afternoon.

### Two things I corrected while building it
- Reliability with 8 bursts can only take steps of 0.125, so the 0.95 I first
  used for the 5 nS case was not representable. More importantly it was the
  wrong failure mode: at 5 nS every command still evokes a burst, so
  reliability holds at 1.00 and the case fails on the inter-burst criterion
  instead. That is now what the animation shows, and it is a sharper story:
  the bursts are still there, they are just no longer the only thing happening.
- The `commandDriven` predicate for the grid outline is inferred from your
  Figure 5B. Check it against the figure before presenting.

### Delivery
Live in a browser is the strongest version but carries risk in a viva. Screen
record the three cases to MP4 and embed those in PowerPoint as the safe
default, keeping the live page open in another window in case someone asks to
see a different cell of the grid.

## 15, 16, 17 — the model section

Sequence: 15 (rig) → model_viz.html (the animation) → 16 (what it means) → 17
(limitations). The animation carries the demonstration, so 16 does not repeat
the grid; it states the gap and the conclusion.

### 15 setup
Three columns: the cell, the inputs, the validation against Zemel 2023 at 40 °C.
Model values that sit within about one SD are green; R_in and the AHP trough
are red, because they do not, and showing that is the point of a validation
table. If everything is green nobody believes it.

The strip at the bottom is the answer to "why a single compartment", and it is
deliberately not "to learn NEURON". The defensible version is that the question
is somatic spike timing, area-calibration to a measured capacitance sets the
correct absolute scale, and voltage dynamics were confirmed area-invariant.
Say that, then say the spatial model is the next phase.

### 16 result
One graphic: a conductance axis with the locked region in green up to 3 nS and
the decoupled region in red beyond, with the two measured values marked and the
gap bracketed. That gap is the entire result, so it gets the whole middle of
the slide.

The conclusion box says "something must suppress LMAN", not "inhibition is
required". That distinction is defended on slide 17 and it is the version that
survives questioning.

### 17 limitations
The three questions from our earlier discussion, each with the honest answer
and no attempt to make it go away.

The middle card is the one to rehearse. Your own Figure 5C shows jitter
crossing the adult target near Q₁₀ = 2, which means faster NMDA kinetics alone
could rescue timing without any inhibition. That is a real alternative
explanation sitting inside your own supplementary figure, and a modeller will
find it. Raising it yourself, and then narrowing the claim to "active
suppression is required, inhibition is the candidate I test", is much stronger
than defending the wider claim.

The Mg²⁺ double-counting question needs actual checking before the viva rather
than just acknowledging: find the holding potential in the source recordings
for the LMAN EPSC amplitudes. If the block is already in those numbers, the
5 and 9.5 nS figures are effective conductances and the headline gap changes
size. It probably still exists, but you want to know before someone asks.
